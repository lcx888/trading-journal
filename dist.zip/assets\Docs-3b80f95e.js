import{j as s}from"./vendor-utils-4aeb5550.js";import{r as j}from"./vendor-react-fa9da516.js";import{aH as M,aC as h,aK as I,a as o,aS as b,aj as f,aT as p,R as N,aQ as g,a8 as u,aG as v,aF as T,a1 as F,aU as S}from"./vendor-antd-01347ada.js";const C=({question:l,answer:t,isOpen:i,onClick:x})=>s.jsxs("div",{className:"border-b border-[#1a1a1f] last:border-0",children:[s.jsxs("button",{className:"w-full py-5 flex items-center justify-between text-left hover:text-[#c9a227] transition-colors",onClick:x,children:[s.jsx("span",{className:"text-sm font-medium text-[#fff] pr-4",children:l}),s.jsx("span",{className:`text-[#666] transition-transform ${i?"rotate-180":""}`,children:s.jsx(S,{})})]}),i&&s.jsx("div",{className:"pb-5 text-sm text-[#888] leading-relaxed whitespace-pre-line",children:t})]}),R=({icon:l,title:t,description:i,onClick:x,isActive:n})=>s.jsx("button",{onClick:x,className:`w-full text-left p-4 rounded-lg border transition-all ${n?"bg-[#0a0a0c] border-[#252528]":"bg-[#111114] border-[#1a1a1f] hover:border-[#252528] hover:bg-[#0a0a0c]"}`,children:s.jsxs("div",{className:"flex items-center gap-3",children:[s.jsx("div",{className:"w-9 h-9 rounded-lg flex items-center justify-center bg-[#1a1a1f] border border-[#252528]",children:s.jsx("span",{className:"text-lg text-[#888]",children:l})}),s.jsxs("div",{children:[s.jsx("h3",{className:`text-sm font-semibold ${n?"text-[#fff]":"text-[#888]"}`,children:t}),s.jsx("p",{className:"text-xs text-[#666]",children:i})]})]})}),r=({icon:l,title:t,children:i})=>s.jsxs("div",{className:"mb-12",children:[s.jsxs("h2",{className:"text-xl font-bold text-[#fff] mb-6 flex items-center gap-3 border-b border-[#1a1a1f] pb-3",children:[s.jsx("span",{className:"text-[#888]",children:l}),t]}),i]}),e=({title:l,children:t})=>s.jsxs("div",{className:"mb-8",children:[s.jsx("h3",{className:"text-base font-semibold text-[#fff] mb-4 border-b border-[#1a1a1f] pb-2",children:l}),s.jsx("div",{className:"text-sm text-[#888] leading-relaxed space-y-4",children:t})]}),d=({steps:l})=>s.jsx("div",{className:"space-y-2",children:l.map((t,i)=>s.jsxs("div",{className:"flex gap-3",children:[s.jsx("div",{className:"w-5 h-5 rounded flex items-center justify-center flex-shrink-0 mt-0.5 bg-[#1a1a1f] border border-[#252528]",children:s.jsx("span",{className:"text-xs font-medium text-[#888]",children:i+1})}),s.jsx("div",{className:"text-sm text-[#888] leading-relaxed",children:t})]},i))}),a=({children:l})=>s.jsx("div",{className:"p-4 rounded border border-[#1a1a1f] bg-[#0a0a0c] text-sm text-[#888]",children:s.jsxs("div",{className:"flex items-start gap-2",children:[s.jsx("span",{className:"text-[#666] mt-0.5",children:"ℹ"}),s.jsx("div",{className:"flex-1",children:l})]})}),$=({onBack:l,onStart:t})=>{const[i,x]=j.useState("quickstart"),[n,y]=j.useState(null),A=[{key:"quickstart",icon:s.jsx(b,{}),title:"快速开始",description:"5 分钟上手"},{key:"import",icon:s.jsx(f,{}),title:"数据导入",description:"多平台支持"},{key:"analysis",icon:s.jsx(p,{}),title:"数据分析",description:"统计与图表"},{key:"ai-coach",icon:s.jsx(N,{}),title:"AI 教练",description:"智能诊断"},{key:"concepts",icon:s.jsx(h,{}),title:"核心概念",description:"术语解释"},{key:"faq",icon:s.jsx(g,{}),title:"常见问题",description:"FAQ"}],E=[{question:"TradeWhy.AI 是什么？有什么用？",answer:`TradeWhy.AI 是一款专为期货交易者设计的 AI 驱动交易复盘平台。

主要功能：
• 交易数据管理：支持多账本管理，自动解析 Jigsaw、ATAS 等主流交易软件导出的数据
• 多维度统计分析：按品种、时段、方向等维度分析您的交易表现
• AI 智能诊断：自动识别交易行为模式，发现潜在问题
• 策略优化建议：基于历史数据回测，提供最优止损、早出策略等建议

适用人群：期货日内交易者、订单流交易者、想要系统性提升交易水平的专业交易员`},{question:"支持哪些交易软件的数据导入？",answer:`目前支持以下交易软件的数据导入：

✅ Jigsaw Daytradr
• 支持 Trade Performance 报告导出的 CSV 文件
• 自动解析 MAE、MFE、Fills、持仓时间等高级字段

✅ ATAS
• 支持交易历史导出的标准格式
• 支持多品种、多账户数据

✅ 通用 CSV 格式
• 支持自定义字段映射
• 最低要求：开仓时间、品种、方向、数量、盈亏

即将支持：NinjaTrader、Sierra Chart、Bookmap 等`},{question:"什么是 MAE 和 MFE？为什么重要？",answer:`MAE（Maximum Adverse Excursion）最大浮亏/最大不利偏移：
• 定义：单笔交易持仓期间，价格向不利方向移动的最大幅度
• 意义：反映您在该笔交易中承受的最大浮亏，评估入场时机和止损设置
• 注意：这是单笔交易的指标，不同于"最大回撤"（账户级别指标）

MFE（Maximum Favorable Excursion）最大浮盈/最大有利偏移：
• 定义：单笔交易持仓期间，价格向有利方向移动的最大幅度  
• 意义：反映该笔交易中您曾经触及的最大浮盈，评估止盈策略效果

为什么重要？
1. 评估执行质量：MFE 很大但实际盈利很小 = 存在动态回撤（利润回吐）问题
2. 优化止损位：分析 MAE 分布，找到最优止损距离
3. 量化心理压力：MAE 越大，持仓期间心理压力越大
4. 改进入场时机：MAE 过大可能意味着入场位置不佳`},{question:"AI 智能诊断是如何工作的？",answer:`AI 智能诊断系统通过分析您的历史交易数据，自动识别以下行为模式：

🔥 报复性交易检测
• 逻辑：检测亏损后 5 分钟内是否立即开新仓
• 意义：冲动交易往往导致连续亏损

⏳ 执行焦虑检测  
• 逻辑：检测成交次数（Fills）是否远大于计划数量
• 意义：频繁加减仓反映执行过程中的犹豫和焦虑

🎯 止损极点检测
• 逻辑：检测止损触发价是否接近 MAE 最低点
• 意义：经常在最低点止损说明止损位设置可能有问题

📊 处置效应诊断
• 逻辑：对比盈利单和亏损单的平均持仓时长
• 意义：如果亏损单持仓更久，说明存在"扛单"倾向

💰 利润留存率分析
• 公式：(MFE - max(0, PnL)) / MFE
• 意义：数值越高，说明利润回吐越严重`},{question:"什么是蒙特卡洛模拟？如何解读结果？",answer:`蒙特卡洛模拟是一种统计学方法，通过大量随机抽样来预测未来可能的结果。

在 TradeWhy.AI 中的应用：
• 基于您的历史胜率和盈亏比
• 随机模拟未来 100 笔交易的结果
• 重复 1000 次模拟
• 统计盈利/亏损/持平的概率分布

如何解读：
• 盈利概率 > 60%：交易系统具有正期望值，可继续执行
• 盈利概率 50-60%：系统边际有效，需要优化
• 盈利概率 < 50%：系统可能存在问题，建议暂停并复盘

注意事项：
• 模拟基于历史数据，不代表未来一定会如此
• 样本量越大（交易越多），模拟结果越可靠
• 建议至少有 50 笔以上交易再进行模拟分析`},{question:'如何找到我的"提款机时段"？',answer:`"提款机时段"是指您历史表现最好的交易时间段。

查看方法：
1. 进入 AI 教练页面
2. 点击"开始分析"
3. 切换到"智能诊断"标签页
4. 查看"期望值分布"图表

期望值计算公式：
期望值 = (胜率 × 平均盈利) - (败率 × 平均亏损)

解读建议：
• 期望值 > 0 的时段：这是您的优势时段，可以加大投入
• 期望值 < 0 的时段：这是您的劣势时段，建议减少或避免交易
• 波动较大的时段：需要更严格的风险控制

常见发现：
• 大多数交易者在开盘前 30 分钟表现较差（情绪波动大）
• 午间时段交易量低，假突破多
• 收盘前可能存在结算压力`},{question:"R倍数是什么？如何计算？",answer:`R倍数（R-Multiple）是衡量单笔交易风险回报比的指标。

计算公式：
R倍数 = 实际盈亏 / 初始风险（|MAE|）

举例说明：
• 您的 MAE 是 -$100（最大浮亏 $100）
• 最终盈利 $250
• R倍数 = 250 / 100 = 2.5R

如何解读：
• R > 2：优秀的交易，盈利是风险的 2 倍以上
• R = 1-2：良好的交易
• R = 0-1：盈利但风险回报一般
• R < 0：亏损交易

为什么使用 R倍数？
• 统一衡量标准：不同品种、不同金额的交易可以横向对比
• 评估交易质量：不仅看赚了多少，更看承担了多少风险
• 优化目标：追求高 R倍数交易，而非高频小利交易`},{question:"最优止损分析是如何计算的？",answer:`最优止损分析通过回测历史数据，模拟不同止损位对总盈亏的影响。

计算逻辑：
1. 设定一系列固定止损值（如 $50, $100, $150...）
2. 对每笔历史交易应用该止损值
3. 如果 MAE 超过止损值，则该笔交易以止损价平仓
4. 计算在该止损设置下的总盈亏
5. 找出使总盈亏最大化的止损值

结果解读：
• 最优止损值：使历史总盈亏最大化的止损距离
• 改善幅度：相比实际结果可能提升的金额
• 触发比例：该止损值会触发多少比例的交易

使用建议：
• 这是基于历史数据的回测，仅供参考
• 不同市场环境可能需要不同止损策略
• 建议结合 ATR 等波动率指标动态调整`},{question:"心理压力评分是如何计算的？",answer:`心理压力评分（1-5 级）基于交易过程中的客观数据评估主观压力。

计算因素：
1. MAE 深度：浮亏越大，压力越大
2. 持仓时间：持仓越久，累积压力越大
3. MAE 与 PnL 关系：如果最终止损，压力系数更高

评分标准：
⭐ 1级：MAE 较小，持仓时间短，顺利盈利离场
⭐⭐ 2级：有一定浮亏，但最终盈利
⭐⭐⭐ 3级：较大浮亏后回本或小盈
⭐⭐⭐⭐ 4级：经历大幅浮亏，长时间持仓
⭐⭐⭐⭐⭐ 5级：极端浮亏，最终止损离场

应用价值：
• 识别高压力交易模式
• 评估心理承受能力
• 优化持仓管理策略
• 预防过度交易和情绪化决策`},{question:"如何导入 Jigsaw Daytradr 的数据？",answer:`从 Jigsaw Daytradr 导出数据的步骤：

1. 打开 Jigsaw Daytradr
2. 进入 Trade Performance 模块
3. 选择要导出的日期范围
4. 点击 Export 按钮
5. 选择 CSV 格式保存

在 TradeWhy.AI 中导入：
1. 登录后进入"数据" → "导入数据"
2. 选择目标账本（或创建新账本）
3. 选择"Jigsaw"作为数据来源
4. 上传 CSV 文件
5. 系统自动解析并导入

支持的字段：
• 基础字段：时间、品种、方向、数量、盈亏
• 高级字段：MAE、MFE、Fills、持仓时间、账户等

提示：
• 建议每日或每周定期导入
• 系统会自动去重，不用担心重复导入
• 导入后可在"交易明细"查看完整数据`},{question:"数据安全吗？会被泄露吗？",answer:`我们非常重视您的数据安全：

数据存储：
• 所有数据加密存储在云端服务器
• 使用 HTTPS 加密传输
• 服务器位于安全的数据中心

访问控制：
• 每个用户只能访问自己的数据
• 密码使用行业标准加密算法存储
• 支持邮箱验证增强账户安全

隐私承诺：
• 我们不会向任何第三方出售或分享您的交易数据
• 不会使用您的数据进行商业分析
• 您可以随时导出或删除自己的数据

建议：
• 使用强密码保护账户
• 定期更换密码
• 不要在公共设备上保存登录状态`},{question:"免费版和付费版有什么区别？",answer:`目前 TradeWhy.AI 完全免费使用！

免费功能包括：
✅ 无限账本创建
✅ 无限交易数据导入
✅ 完整的统计分析功能
✅ AI 智能诊断系统
✅ 蒙特卡洛模拟
✅ 最优止损分析
✅ 行为归因标签
✅ 数据导出功能

未来可能的付费功能（规划中）：
• 实时数据同步
• 团队协作功能
• 高级报告定制
• API 接口调用
• 优先技术支持

我们的目标是让每位交易者都能免费使用核心功能，持续提升交易水平。`},{question:"遇到问题如何获取帮助？",answer:`如果您在使用过程中遇到任何问题：

自助解决：
1. 查看本页面的常见问题解答
2. 阅读使用文档和操作指南
3. 检查数据格式是否符合要求

联系我们：
• 发送邮件描述您的问题
• 提供截图或错误信息
• 我们会在 24 小时内回复

反馈建议：
• 我们欢迎任何功能建议和改进意见
• 您的反馈将帮助我们不断完善产品

常见问题自查：
• 导入失败 → 检查 CSV 文件格式是否正确
• 数据不显示 → 刷新页面或检查账本选择
• 分析结果异常 → 确认数据量是否足够（建议 50 笔以上）`}],w=()=>{switch(i){case"quickstart":return s.jsx(s.Fragment,{children:s.jsxs(r,{icon:s.jsx(b,{}),title:"快速开始",children:[s.jsxs("div",{className:"mb-6 p-4 border border-[#1a1a1f] bg-[#0a0a0c] rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#fff] font-medium mb-2",children:"为什么需要 TradeWhy.AI？"}),s.jsx("p",{className:"text-sm text-[#888] leading-relaxed",children:'作为交易者，您是否遇到过这些问题：不知道自己为什么亏损？不知道哪个时段交易最赚钱？不知道止损应该设在哪里？ TradeWhy.AI 通过 AI 深度分析您的每笔交易，自动发现交易中的问题，给出科学的优化建议，帮您从"凭感觉交易"升级到"数据驱动交易"。'})]}),s.jsxs(e,{title:"1. 注册账号（30秒完成）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"为什么需要注册？"})," 注册后，您的所有交易数据将安全存储在云端，无论在哪里登录都能查看。 更重要的是，系统会记住您的分析历史，持续追踪您的进步轨迹。"]}),s.jsx("p",{className:"mb-3 text-[#fff] font-medium",children:"带来的好处："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mb-4 text-sm",children:[s.jsx("li",{children:"数据永不丢失，换设备也能访问"}),s.jsx("li",{children:"自动保存分析报告，随时回顾"}),s.jsx("li",{children:"多设备同步，随时随地复盘"})]}),s.jsx(d,{steps:['访问 TradeWhy.AI 官网，点击右上角"免费开始"',"输入您的邮箱地址（用于登录和找回密码）","设置一个强密码（建议包含大小写字母、数字）",'点击"注册"按钮，系统自动创建账号',"注册成功后自动登录，进入主界面"]}),s.jsxs(a,{type:"info",children:[s.jsx("strong",{children:"小贴士："})," 注册后建议立即验证邮箱，这样如果忘记密码可以快速找回。 整个注册过程只需 30 秒，完全免费，无需信用卡。"]})]}),s.jsxs(e,{title:"2. 创建账本（1分钟完成）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"什么是账本？为什么需要它？"}),"账本就像文件夹，帮您把不同来源的交易数据分类管理。 比如您有主账户和模拟账户，或者同时使用日内策略和波段策略，创建不同账本可以让您分别分析，互不干扰。"]}),s.jsx("p",{className:"mb-3 text-[#fff] font-medium",children:"带来的好处："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mb-4 text-sm",children:[s.jsx("li",{children:"清晰区分不同账户或策略的表现"}),s.jsx("li",{children:"独立分析，避免数据混淆"}),s.jsx("li",{children:"方便对比不同策略的优劣"}),s.jsx("li",{children:"可以随时切换查看不同账本的数据"})]}),s.jsx("p",{className:"mb-2",children:s.jsx("strong",{className:"text-[#fff]",children:"实际场景举例："})}),s.jsxs("div",{className:"bg-[#0a0a0c] rounded-lg p-3 border border-[#1a1a1f] mb-4 text-xs",children:[s.jsx("p",{className:"text-[#888] mb-2",children:"场景 1：您有两个交易账户"}),s.jsx("p",{className:"text-[#666]",children:'→ 创建"主账户"和"备用账户"两个账本，分别导入数据，可以清楚看到哪个账户表现更好'}),s.jsx("p",{className:"text-[#888] mt-3 mb-2",children:"场景 2：您测试新策略"}),s.jsx("p",{className:"text-[#666]",children:'→ 创建"新策略测试"账本，单独分析新策略的表现，不影响原有数据的统计'})]}),s.jsx(d,{steps:['登录后，点击左侧菜单"数据" → "账本管理"','点击页面右上角"新建账本"按钮','输入账本名称（建议用有意义的名称，如"主账户-2024"、"日内策略"等）','点击"确认"按钮，账本创建完成',"创建后可以立即开始导入数据，也可以稍后导入"]}),s.jsxs(a,{type:"success",children:[s.jsx("strong",{children:"专业建议："}),' 建议为每个交易账户或策略创建独立账本。 这样您可以清楚地看到"哪个账户更赚钱"、"哪个策略更稳定"，从而优化资金分配。']})]}),s.jsxs(e,{title:"3. 导入交易数据（2分钟完成）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"为什么需要导入数据？"}),"TradeWhy.AI 的强大之处在于它能分析您的真实交易数据。 导入数据后，系统会自动计算各种指标，识别交易模式，发现您自己可能都没意识到的问题。"]}),s.jsx("p",{className:"mb-3 text-[#fff] font-medium",children:"带来的好处："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mb-4 text-sm",children:[s.jsx("li",{children:"自动计算胜率、利润因子、期望值等关键指标"}),s.jsx("li",{children:'识别您的"提款机时段"和"碎钞机时段"'}),s.jsx("li",{children:"发现交易行为问题（如报复性交易、处置效应）"}),s.jsx("li",{children:"给出科学的优化建议（如最优止损位、早出策略）"}),s.jsx("li",{children:"预测未来交易的成功概率（蒙特卡洛模拟）"})]}),s.jsx("p",{className:"mb-2",children:s.jsx("strong",{className:"text-[#fff]",children:"支持的数据来源："})}),s.jsxs("div",{className:"grid md:grid-cols-2 gap-3 mb-4",children:[s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1 text-sm",children:"✅ Jigsaw Daytradr"}),s.jsx("p",{className:"text-xs text-[#666]",children:"自动解析 MAE、MFE、Fills 等高级字段，分析最全面"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1 text-sm",children:"✅ ATAS"}),s.jsx("p",{className:"text-xs text-[#666]",children:"支持标准交易历史导出格式"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1 text-sm",children:"✅ 通用 CSV"}),s.jsx("p",{className:"text-xs text-[#666]",children:"任何交易软件导出的 CSV 都可以导入"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1 text-sm",children:"✅ 手动录入"}),s.jsx("p",{className:"text-xs text-[#666]",children:"如果没有电子记录，也可以手动输入"})]})]}),s.jsx(d,{steps:["从您的交易软件（Jigsaw/ATAS 等）导出 CSV 格式的交易记录",'登录 TradeWhy.AI，进入"数据" → "导入数据"',"选择目标账本（刚才创建的账本）","选择数据来源类型（Jigsaw/ATAS/通用CSV）","点击上传区域或直接拖拽 CSV 文件到页面","系统自动解析文件，显示预览（检查数据是否正确）",'确认无误后点击"导入"按钮',"等待几秒钟，系统完成导入并显示成功提示"]}),s.jsxs(a,{type:"warning",children:[s.jsx("strong",{children:"重要提示："})," 建议至少导入 50 笔以上的交易数据，数据越多分析结果越准确。 如果只有几笔交易，AI 分析可能无法得出有价值的结论。"]}),s.jsxs("div",{className:"mt-4 p-4 bg-[#10b981]/10 border border-[#10b981]/20 rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#10b981] font-medium mb-2",children:"🎯 导入后立即能看到什么？"}),s.jsxs("ul",{className:"text-xs text-[#888] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"总盈亏、总交易次数、胜率等基础统计"}),s.jsx("li",{children:"按品种、方向、时段的盈亏分布"}),s.jsx("li",{children:"权益曲线图（看到资金变化趋势）"}),s.jsx("li",{children:"最大回撤点（知道最坏情况下的亏损）"})]})]})]}),s.jsxs(e,{title:"4. 开始使用 AI 分析（立即获得洞察）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"这是 TradeWhy.AI 的核心价值所在！"}),"数据导入后，系统会自动进行深度分析，发现您交易中的问题和机会。 这些洞察是您自己复盘很难发现的，因为 AI 能同时分析数百笔交易，找出隐藏的模式。"]}),s.jsx("p",{className:"mb-3 text-[#c9a227]",children:"✓ 您将获得："}),s.jsxs("div",{className:"grid md:grid-cols-2 gap-4 mb-4",children:[s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsxs("div",{className:"text-[#c9a227] font-semibold mb-2 flex items-center gap-2",children:[s.jsx(u,{})," 智能诊断"]}),s.jsx("p",{className:"text-xs text-[#888] mb-2",children:"自动发现交易行为问题："}),s.jsxs("ul",{className:"text-xs text-[#666] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"是否经常报复性交易？"}),s.jsx("li",{children:"是否存在处置效应？"}),s.jsx("li",{children:"执行是否犹豫不决？"}),s.jsx("li",{children:"利润回吐是否严重？"})]})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsxs("div",{className:"text-[#c9a227] font-semibold mb-2 flex items-center gap-2",children:[s.jsx(v,{})," 策略优化"]}),s.jsx("p",{className:"text-xs text-[#888] mb-2",children:"科学的优化建议："}),s.jsxs("ul",{className:"text-xs text-[#666] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"最优止损位是多少？"}),s.jsx("li",{children:"应该在哪个时段交易？"}),s.jsx("li",{children:"是否需要调整止盈策略？"}),s.jsx("li",{children:"未来交易成功概率？"})]})]})]}),s.jsx(d,{steps:['数据导入完成后，点击左侧菜单"AI 教练"','选择要分析的账本（或选择"全部账本"分析所有数据）',"可选：设置日期范围筛选（如只分析最近 3 个月）",'点击"开始分析"按钮',"等待 5-10 秒，系统完成分析（数据越多时间稍长）",'查看分析报告，重点关注"智能诊断"标签页']}),s.jsxs("div",{className:"mt-4 p-4 border border-[#1a1a1f] bg-[#0a0a0c] rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#fff] font-medium mb-2",children:"真实案例："}),s.jsxs("p",{className:"text-xs text-[#888] leading-relaxed mb-2",children:[s.jsx("strong",{className:"text-[#fff]",children:"用户 A 的发现："})," 通过 AI 分析，发现自己 90% 的亏损都发生在上午 9:30-10:00 这个时段。 原因是开盘后情绪波动大，容易冲动交易。之后他避开这个时段，胜率从 45% 提升到 58%。"]}),s.jsxs("p",{className:"text-xs text-[#888] leading-relaxed",children:[s.jsx("strong",{className:"text-[#fff]",children:"用户 B 的发现："}),' AI 诊断出他存在严重的"利润回吐"问题， 平均利润留存率只有 30%（意味着赚了 $1000 但只拿到 $300）。通过采用"早出策略"， 虽然单笔盈利变小，但总盈利反而提升了 40%。']})]})]}),s.jsxs(e,{title:"5. 持续改进（建立交易系统）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"交易不是一次性的，而是持续改进的过程。"}),"TradeWhy.AI 的价值不仅在于发现问题，更在于帮您建立数据驱动的交易系统。 每次交易后导入数据，定期查看分析报告，根据建议调整策略，您的交易水平会持续提升。"]}),s.jsx("p",{className:"mb-3 text-[#c9a227]",children:"✓ 建立持续改进循环："}),s.jsxs("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mb-4",children:[s.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[s.jsx("div",{className:"w-8 h-8 rounded-full bg-[#c9a227]/20 flex items-center justify-center flex-shrink-0",children:s.jsx("span",{className:"text-[#c9a227] font-bold text-sm",children:"1"})}),s.jsxs("div",{children:[s.jsx("div",{className:"text-sm font-semibold text-[#fff]",children:"交易"}),s.jsx("div",{className:"text-xs text-[#666]",children:"执行您的交易策略"})]})]}),s.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[s.jsx("div",{className:"w-8 h-8 rounded-full bg-[#c9a227]/20 flex items-center justify-center flex-shrink-0",children:s.jsx("span",{className:"text-[#c9a227] font-bold text-sm",children:"2"})}),s.jsxs("div",{children:[s.jsx("div",{className:"text-sm font-semibold text-[#fff]",children:"导入数据"}),s.jsx("div",{className:"text-xs text-[#666]",children:"定期（每天/每周）导入交易记录到 TradeWhy.AI"})]})]}),s.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[s.jsx("div",{className:"w-8 h-8 rounded-full bg-[#c9a227]/20 flex items-center justify-center flex-shrink-0",children:s.jsx("span",{className:"text-[#c9a227] font-bold text-sm",children:"3"})}),s.jsxs("div",{children:[s.jsx("div",{className:"text-sm font-semibold text-[#fff]",children:"AI 分析"}),s.jsx("div",{className:"text-xs text-[#666]",children:"查看分析报告，了解交易表现和问题"})]})]}),s.jsxs("div",{className:"flex items-center gap-3",children:[s.jsx("div",{className:"w-8 h-8 rounded-full bg-[#c9a227]/20 flex items-center justify-center flex-shrink-0",children:s.jsx("span",{className:"text-[#c9a227] font-bold text-sm",children:"4"})}),s.jsxs("div",{children:[s.jsx("div",{className:"text-sm font-semibold text-[#fff]",children:"优化策略"}),s.jsx("div",{className:"text-xs text-[#666]",children:"根据 AI 建议调整止损、止盈、交易时段等"})]})]})]}),s.jsxs(a,{type:"success",children:[s.jsx("strong",{children:"专业交易者的习惯："})," 建议每周至少复盘一次，每月做一次深度分析。 不要等到亏损严重才想起来复盘，持续的小改进比偶尔的大调整更有效。"]})]})]})});case"import":return s.jsx(s.Fragment,{children:s.jsxs(r,{icon:s.jsx(f,{}),title:"数据导入",children:[s.jsxs("div",{className:"mb-6 p-4 border border-[#1a1a1f] bg-[#0a0a0c] rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#fff] font-medium mb-2",children:"为什么数据导入很重要？"}),s.jsx("p",{className:"text-sm text-[#888] leading-relaxed mb-3",children:"数据是分析的基础。导入的数据越完整，AI 分析的结果就越准确、越有价值。 特别是 MAE、MFE 这些高级字段，能让系统发现很多肉眼看不到的问题。"}),s.jsxs("p",{className:"text-sm text-[#888] leading-relaxed",children:[s.jsx("strong",{className:"text-[#fff]",children:"数据质量决定分析质量："}),'如果您只导入基础的盈亏数据，系统只能做简单的统计。 但如果导入包含 MAE/MFE 的数据，系统就能分析"利润回吐"、"止损位置"、"心理压力"等深层问题。']})]}),s.jsxs(e,{title:"Jigsaw Daytradr 数据导入（推荐）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"为什么推荐 Jigsaw？"}),"Jigsaw 是专业的订单流交易软件，导出的数据包含最完整的信息： MAE（最大浮亏）、MFE（最大浮盈）、Fills（成交次数）、持仓时间等。 这些数据能让 TradeWhy.AI 进行最深入的分析。"]}),s.jsx("p",{className:"mb-3 text-[#fff] font-medium",children:"使用 Jigsaw 数据您能获得："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mb-4 text-sm",children:[s.jsx("li",{children:"完整的 MAE/MFE 分析（知道每笔交易的波动区间）"}),s.jsx("li",{children:"利润留存率计算（发现利润回吐问题）"}),s.jsx("li",{children:"心理压力评分（了解交易时的压力等级）"}),s.jsx("li",{children:"执行质量评估（通过 Fills 判断是否犹豫）"}),s.jsx("li",{children:"最优止损分析（基于真实 MAE 数据）"})]}),s.jsx("h4",{className:"text-sm font-semibold text-[#fff] mt-4 mb-2",children:"步骤 1：从 Jigsaw 导出数据"}),s.jsx(d,{steps:["打开 Jigsaw Daytradr 软件",'在顶部菜单找到 "Trade Performance" 或 "交易表现" 模块',"在日期选择器中，选择您要导出的日期范围（建议按月或按周导出）","确认交易列表显示正确",'点击右上角的 "Export" 或 "导出" 按钮','在弹出的对话框中选择 "CSV" 格式',"选择保存位置，建议保存在桌面方便查找",'点击"保存"，等待导出完成']}),s.jsxs(a,{type:"info",children:[s.jsx("strong",{children:"小贴士："})," 建议每次交易后定期导出（如每周一次），这样数据更新及时，分析结果更准确。 不要等到积累几个月才导出，数据量太大可能影响导入速度。"]}),s.jsx("h4",{className:"text-sm font-semibold text-[#fff] mt-6 mb-2",children:"步骤 2：在 TradeWhy.AI 中导入"}),s.jsx(d,{steps:['登录 TradeWhy.AI，点击左侧菜单"数据" → "导入数据"',"在页面顶部选择目标账本（如果还没有账本，先创建账本）",'在"数据来源"下拉菜单中选择"Jigsaw"',"点击上传区域，或直接将 CSV 文件拖拽到上传区域","系统自动开始解析文件，显示解析进度","解析完成后，系统会显示数据预览（检查是否正确）","确认字段映射无误（系统会自动识别，一般不需要手动调整）",'点击"导入"按钮，等待导入完成',"导入成功后，系统会显示导入的交易数量"]}),s.jsxs("div",{className:"mt-4 p-4 border border-[#1a1a1f] bg-[#0a0a0c] rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#fff] font-medium mb-2",children:"导入成功后会看到："}),s.jsxs("ul",{className:"text-xs text-[#888] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:'导入的交易笔数（如"成功导入 127 笔交易"）'}),s.jsx("li",{children:'如果有重复数据，会提示"跳过 X 笔重复交易"'}),s.jsx("li",{children:'如果有格式错误，会提示"X 笔交易格式错误，已跳过"'}),s.jsx("li",{children:'可以立即点击"查看交易明细"查看导入的数据'})]})]}),s.jsxs(a,{type:"warning",className:"mt-4",children:[s.jsx("strong",{children:"常见问题："})," 如果导入失败，请检查： (1) CSV 文件是否是从 Jigsaw 正确导出的；(2) 文件是否损坏；(3) 日期格式是否正确。 如果仍有问题，可以尝试用 Excel 打开 CSV 文件，检查数据格式。"]})]}),s.jsxs(e,{title:"ATAS 数据导入",children:[s.jsx("p",{children:"ATAS 是另一款流行的订单流分析软件。"}),s.jsx(d,{steps:["在 ATAS 中打开交易历史","选择日期范围","导出为 CSV 格式",'在 TradeWhy.AI 中选择"ATAS"作为数据来源',"上传文件完成导入"]})]}),s.jsxs(e,{title:"通用 CSV 格式",children:[s.jsx("p",{children:"如果您使用其他交易软件，可以使用通用 CSV 格式导入。"}),s.jsx("h4",{className:"text-sm font-semibold text-[#fff] mt-4 mb-2",children:"必需字段："}),s.jsxs("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] font-mono text-xs",children:[s.jsx("div",{className:"text-[#c9a227]",children:"Open Time"}),s.jsx("div",{className:"text-[#888]",children:"开仓时间，格式：YYYY-MM-DD HH:mm:ss"}),s.jsx("div",{className:"text-[#c9a227] mt-2",children:"Instrument"}),s.jsx("div",{className:"text-[#888]",children:"品种代码，如 NQ、ES、GC"}),s.jsx("div",{className:"text-[#c9a227] mt-2",children:"Side / Direction"}),s.jsx("div",{className:"text-[#888]",children:"方向，Long/Short 或 Buy/Sell"}),s.jsx("div",{className:"text-[#c9a227] mt-2",children:"Quantity"}),s.jsx("div",{className:"text-[#888]",children:"数量"}),s.jsx("div",{className:"text-[#c9a227] mt-2",children:"PnL / Profit"}),s.jsx("div",{className:"text-[#888]",children:"盈亏金额"})]}),s.jsx("h4",{className:"text-sm font-semibold text-[#fff] mt-4 mb-2",children:"可选字段（增强分析）："}),s.jsx("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] font-mono text-xs",children:s.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[s.jsxs("div",{children:[s.jsx("span",{className:"text-[#c9a227]",children:"MAE"})," - 最大浮亏（最大不利偏移）"]}),s.jsxs("div",{children:[s.jsx("span",{className:"text-[#c9a227]",children:"MFE"})," - 最大浮盈（最大有利偏移）"]}),s.jsxs("div",{children:[s.jsx("span",{className:"text-[#c9a227]",children:"Fills"})," - 成交次数"]}),s.jsxs("div",{children:[s.jsx("span",{className:"text-[#c9a227]",children:"Time In"})," - 持仓时间"]}),s.jsxs("div",{children:[s.jsx("span",{className:"text-[#c9a227]",children:"Close Time"})," - 平仓时间"]}),s.jsxs("div",{children:[s.jsx("span",{className:"text-[#c9a227]",children:"Account"})," - 账户"]})]})})]}),s.jsxs(e,{title:"数据去重机制",children:[s.jsx("p",{children:"系统会自动检测并跳过重复的交易记录，判断依据："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-2",children:[s.jsx("li",{children:"相同的开仓时间"}),s.jsx("li",{children:"相同的品种"}),s.jsx("li",{children:"相同的方向"}),s.jsx("li",{children:"相同的盈亏金额"})]}),s.jsx(a,{type:"success",children:"您可以放心地重复导入同一时间段的数据，系统不会产生重复记录。"})]})]})});case"analysis":return s.jsx(s.Fragment,{children:s.jsxs(r,{icon:s.jsx(p,{}),title:"数据分析",children:[s.jsxs(e,{title:"总览仪表盘",children:[s.jsx("p",{children:"总览页面展示您的整体交易表现，包括："}),s.jsxs("div",{className:"grid md:grid-cols-3 gap-4 mt-4",children:[s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-2",children:"权益曲线"}),s.jsx("p",{className:"text-xs",children:"累计盈亏走势图，标注最大回撤点"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-2",children:"关键指标"}),s.jsx("p",{className:"text-xs",children:"胜率、利润因子、期望值、最大回撤等"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-2",children:"多维度统计"}),s.jsx("p",{className:"text-xs",children:"按品种、方向、时段分组分析"})]})]})]}),s.jsxs(e,{title:"交易明细",children:[s.jsx("p",{children:"交易明细页面提供完整的交易记录表格，支持："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-2",children:[s.jsxs("li",{children:[s.jsx("strong",{children:"筛选功能"}),"：按品种、方向、日期范围、盈亏状态筛选"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"排序功能"}),"：按任意列排序"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"详情查看"}),"：点击单笔交易查看完整分析"]}),s.jsxs("li",{children:[s.jsx("strong",{children:"数据导出"}),"：导出为 Excel 格式"]})]}),s.jsx("h4",{className:"text-sm font-semibold text-[#fff] mt-4 mb-2",children:"交易明细新增列（AI 增强）："}),s.jsxs("div",{className:"space-y-2",children:[s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-[#c9a227] font-semibold",children:"R倍数"}),s.jsx("span",{className:"text-[#888] text-xs ml-2",children:"风险回报比 = PnL / |MAE|"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-[#c9a227] font-semibold",children:"留存率"}),s.jsx("span",{className:"text-[#888] text-xs ml-2",children:"利润留存比例，越低越好"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-[#c9a227] font-semibold",children:"压力"}),s.jsx("span",{className:"text-[#888] text-xs ml-2",children:"1-5 级心理压力评分"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-[#c9a227] font-semibold",children:"诊断"}),s.jsx("span",{className:"text-[#888] text-xs ml-2",children:"自动归因标签（获利回吐/止损极点等）"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-[#c9a227] font-semibold",children:"波动区间"}),s.jsx("span",{className:"text-[#888] text-xs ml-2",children:"MAE/MFE 可视化条形图"})]})]})]}),s.jsx(e,{title:"统计指标说明",children:s.jsxs("div",{className:"space-y-4",children:[s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1",children:"胜率 (Win Rate)"}),s.jsx("p",{className:"text-xs text-[#888]",children:"盈利交易数 / 总交易数 × 100%"}),s.jsx("p",{className:"text-xs text-[#666] mt-1",children:"一般认为 50% 以上为良好，但需结合盈亏比评估"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1",children:"利润因子 (Profit Factor)"}),s.jsx("p",{className:"text-xs text-[#888]",children:"总盈利 / 总亏损（绝对值）"}),s.jsx("p",{className:"text-xs text-[#666] mt-1",children:">1 表示盈利，>2 表示优秀"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1",children:"期望值 (Expectancy)"}),s.jsx("p",{className:"text-xs text-[#888]",children:"(胜率 × 平均盈利) - (败率 × 平均亏损)"}),s.jsx("p",{className:"text-xs text-[#666] mt-1",children:"正值表示系统长期盈利，负值应停止交易"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1",children:"最大回撤 (Max Drawdown)"}),s.jsx("p",{className:"text-xs text-[#888]",children:"权益曲线从峰值到谷底的最大跌幅"}),s.jsx("p",{className:"text-xs text-[#666] mt-1",children:"反映最坏情况下的亏损幅度"})]})]})})]})});case"ai-coach":return s.jsx(s.Fragment,{children:s.jsxs(r,{icon:s.jsx(N,{}),title:"AI 交易教练",children:[s.jsxs("div",{className:"mb-6 p-4 border border-[#1a1a1f] bg-[#0a0a0c] rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#fff] font-medium mb-2",children:"为什么需要 AI 交易教练？"}),s.jsx("p",{className:"text-sm text-[#888] leading-relaxed mb-3",children:'作为交易者，您可能经常问自己："我为什么亏损？"、"我哪里做错了？"、"我应该怎么改进？" 但靠自己复盘，往往只能看到表面的盈亏，很难发现深层次的问题。'}),s.jsxs("p",{className:"text-sm text-[#888] leading-relaxed",children:[s.jsx("strong",{className:"text-[#fff]",children:"AI 交易教练的价值："}),"它能同时分析您数百笔交易，找出您自己都意识不到的行为模式。 比如：您是否经常在亏损后立即开新仓（报复性交易）？您是否过早止盈、过晚止损（处置效应）？ 您的止损位是否总是设在最低点？这些问题，AI 都能自动发现并给出改进建议。"]})]}),s.jsxs(e,{title:"功能概述 - 四大核心能力",children:[s.jsx("p",{className:"mb-4",children:"AI 交易教练提供四个核心功能，每个功能都针对交易中的关键问题："}),s.jsxs("div",{className:"grid md:grid-cols-2 gap-4 mb-6",children:[s.jsxs("div",{className:"p-5 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f] hover:border-[#c9a227]/40 transition-all",children:[s.jsxs("div",{className:"text-[#fff] font-semibold mb-2 text-base flex items-center gap-2",children:[s.jsx(u,{})," 智能诊断"]}),s.jsx("p",{className:"text-xs text-[#888] mb-3",children:"自动识别交易行为模式和潜在问题"}),s.jsx("p",{className:"text-xs text-[#666] mb-2",children:s.jsx("strong",{className:"text-[#fff]",children:"能发现："})}),s.jsxs("ul",{className:"text-xs text-[#666] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"报复性交易（亏损后冲动开仓）"}),s.jsx("li",{children:"处置效应（过早止盈过晚止损）"}),s.jsx("li",{children:"执行犹豫（频繁加减仓）"}),s.jsx("li",{children:"利润回吐（MFE 大但盈利小）"}),s.jsx("li",{children:"止损极点（总是在最低点止损）"})]}),s.jsx("p",{className:"text-xs text-[#666] mt-3",children:"价值：发现您自己意识不到的交易陋习"})]}),s.jsxs("div",{className:"p-5 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f] hover:border-[#c9a227]/40 transition-all",children:[s.jsxs("div",{className:"text-[#fff] font-semibold mb-2 text-base flex items-center gap-2",children:[s.jsx(v,{})," 蒙特卡洛模拟"]}),s.jsx("p",{className:"text-xs text-[#888] mb-3",children:"预测未来交易的盈亏概率分布"}),s.jsx("p",{className:"text-xs text-[#666] mb-2",children:s.jsx("strong",{className:"text-[#fff]",children:"能预测："})}),s.jsxs("ul",{className:"text-xs text-[#666] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"未来 100 笔交易的盈利概率"}),s.jsx("li",{children:"可能的最大回撤幅度"}),s.jsx("li",{children:"账户资金变化趋势"}),s.jsx("li",{children:"系统是否具有正期望值"})]}),s.jsx("p",{className:"text-xs text-[#c9a227] mt-3 font-medium",children:"✓ 价值：提前知道系统是否值得继续使用"})]}),s.jsxs("div",{className:"p-5 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f] hover:border-[#c9a227]/40 transition-all",children:[s.jsxs("div",{className:"text-[#fff] font-semibold mb-2 text-base flex items-center gap-2",children:[s.jsx(T,{})," 最优止损分析"]}),s.jsx("p",{className:"text-xs text-[#888] mb-3",children:"回测不同止损位的效果，推荐最优策略"}),s.jsx("p",{className:"text-xs text-[#666] mb-2",children:s.jsx("strong",{className:"text-[#fff]",children:"能优化："})}),s.jsxs("ul",{className:"text-xs text-[#666] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"找到使总盈亏最大化的止损距离"}),s.jsx("li",{children:"计算改善幅度（可能多赚多少钱）"}),s.jsx("li",{children:"评估不同止损位的触发频率"}),s.jsx("li",{children:"建议动态止损策略"})]}),s.jsx("p",{className:"text-xs text-[#c9a227] mt-3 font-medium",children:"✓ 价值：科学地设置止损，而不是凭感觉"})]}),s.jsxs("div",{className:"p-5 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f] hover:border-[#c9a227]/40 transition-all",children:[s.jsxs("div",{className:"text-[#fff] font-semibold mb-2 text-base flex items-center gap-2",children:[s.jsx(F,{})," 期望值分布"]}),s.jsx("p",{className:"text-xs text-[#888] mb-3",children:"按时段/方向/品种分析，找出优势时段"}),s.jsx("p",{className:"text-xs text-[#666] mb-2",children:s.jsx("strong",{className:"text-[#fff]",children:"能发现："})}),s.jsxs("ul",{className:"text-xs text-[#666] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:'您的"提款机时段"（最赚钱的时间）'}),s.jsx("li",{children:'您的"碎钞机时段"（最亏钱的时间）'}),s.jsx("li",{children:"哪个品种表现最好/最差"}),s.jsx("li",{children:"做多和做空的期望值差异"})]}),s.jsx("p",{className:"text-xs text-[#c9a227] mt-3 font-medium",children:"✓ 价值：在优势时段加大投入，避开劣势时段"})]})]})]}),s.jsxs(e,{title:"详细使用步骤（5分钟获得完整诊断）",children:[s.jsxs("p",{className:"mb-3",children:[s.jsx("strong",{className:"text-[#fff]",children:"使用 AI 教练非常简单，只需 5 分钟就能获得完整的诊断报告。"}),"系统会自动分析您的所有交易数据，不需要您做任何复杂的设置。"]}),s.jsx(d,{steps:['登录 TradeWhy.AI，点击左侧菜单"AI 教练"','在页面顶部选择要分析的账本（可以选择单个账本，或选择"全部账本"分析所有数据）',"可选：如果只想分析特定时间段，点击日期筛选器，选择开始和结束日期",'点击页面中央的"开始分析"按钮',"等待 5-10 秒（数据越多时间稍长，通常不超过 30 秒）","分析完成后，页面自动显示结果",'点击"智能诊断"标签页，查看详细的诊断报告']}),s.jsxs(a,{type:"info",className:"mt-4",children:[s.jsx("strong",{children:"数据要求："})," 建议至少有 50 笔以上交易数据再进行 AI 分析。 数据越多，分析结果越准确。如果只有几笔交易，系统可能无法得出有价值的结论。"]}),s.jsxs("div",{className:"mt-4 p-4 border border-[#1a1a1f] bg-[#0a0a0c] rounded-lg",children:[s.jsx("p",{className:"text-sm text-[#fff] font-medium mb-2",children:"分析完成后您将看到："}),s.jsxs("ul",{className:"text-xs text-[#888] space-y-1 list-disc list-inside",children:[s.jsx("li",{children:"综合操作建议（继续执行/早出策略/减仓/多看少动）"}),s.jsx("li",{children:"优化行动清单（按优先级排序的改进建议）"}),s.jsx("li",{children:"期望值分布图（哪个时段/品种/方向最赚钱）"}),s.jsx("li",{children:"蒙特卡洛模拟结果（未来交易成功概率）"}),s.jsx("li",{children:"最优止损分析（推荐的最佳止损距离）"}),s.jsx("li",{children:"行为特征面板（检测到的交易行为问题）"})]})]})]}),s.jsxs(e,{title:"行为归因标签",children:[s.jsx("p",{children:"系统会自动为每笔交易和整体表现打上行为标签："}),s.jsxs("div",{className:"space-y-3 mt-4",children:[s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-xs px-2 py-1 bg-[#f43f5e]/20 text-[#f43f5e] rounded mr-2",children:"🔥 报复性交易"}),s.jsx("span",{className:"text-xs text-[#888]",children:"亏损后 5 分钟内开新仓，冲动交易倾向"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-xs px-2 py-1 bg-[#eab308]/20 text-[#eab308] rounded mr-2",children:"⏳ 执行犹豫"}),s.jsx("span",{className:"text-xs text-[#888]",children:"成交次数过多，反映入场/出场不果断"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-xs px-2 py-1 bg-[#8b5cf6]/20 text-[#8b5cf6] rounded mr-2",children:"🎯 止损极点"}),s.jsx("span",{className:"text-xs text-[#888]",children:"止损价接近 MAE 最低点，可能止损位不合理"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-xs px-2 py-1 bg-[#3b82f6]/20 text-[#3b82f6] rounded mr-2",children:"📉 处置效应"}),s.jsx("span",{className:"text-xs text-[#888]",children:"亏损单持仓时间长于盈利单，扛单倾向"})]}),s.jsxs("div",{className:"p-3 bg-[#0a0a0c] rounded border border-[#1a1a1f]",children:[s.jsx("span",{className:"text-xs px-2 py-1 bg-[#10b981]/20 text-[#10b981] rounded mr-2",children:"💰 利润回吐"}),s.jsx("span",{className:"text-xs text-[#888]",children:"MFE 与实际盈利差距大，止盈不及时"})]})]})]}),s.jsxs(e,{title:"操作建议解读",children:[s.jsx("p",{children:"系统会基于诊断结果给出下周操作建议："}),s.jsxs("div",{className:"space-y-3 mt-4",children:[s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#10b981] font-semibold mb-1",children:"✅ 继续执行"}),s.jsx("p",{className:"text-xs text-[#888]",children:"交易系统运行良好，保持当前策略"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#c9a227] font-semibold mb-1",children:"⚡ 早出策略"}),s.jsx("p",{className:"text-xs text-[#888]",children:"利润留存率低，建议更快止盈，减少利润回吐"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#eab308] font-semibold mb-1",children:"📉 减仓操作"}),s.jsx("p",{className:"text-xs text-[#888]",children:"近期表现不佳，建议降低仓位，控制风险"})]}),s.jsxs("div",{className:"p-4 bg-[#0a0a0c] rounded-lg border border-[#1a1a1f]",children:[s.jsx("div",{className:"text-[#f43f5e] font-semibold mb-1",children:"🛑 多看少动"}),s.jsx("p",{className:"text-xs text-[#888]",children:"系统表现较差，建议暂停交易，深入复盘"})]})]})]})]})});case"concepts":return s.jsx(s.Fragment,{children:s.jsxs(r,{icon:s.jsx(h,{}),title:"核心概念",children:[s.jsxs(e,{title:"MAE（最大浮亏 / 最大不利偏移）",children:[s.jsx("p",{children:s.jsx("strong",{children:"Maximum Adverse Excursion - 最大不利偏移"})}),s.jsx("p",{className:"mt-2",children:"定义：单笔交易持仓期间，价格向不利方向移动的最大幅度（即最大浮亏）。"}),s.jsx("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mt-3",children:s.jsx("p",{className:"text-xs",children:"举例：您做多后，价格最低跌到了 -$200，即使最后盈利，MAE = $200（最大浮亏 $200）"})}),s.jsx("p",{className:"mt-3",children:"意义："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-1",children:[s.jsx("li",{children:"反映单笔交易中您承受的最大浮亏压力"}),s.jsx("li",{children:"用于评估入场时机和止损位是否合理"}),s.jsx("li",{children:"帮助计算 R倍数（风险回报比）"}),s.jsx("li",{children:"量化交易过程中的心理压力"})]}),s.jsx(a,{type:"info",children:'注意：MAE 是单笔交易的指标，不同于"最大回撤"。最大回撤是资金曲线从峰值下跌的幅度，是账户级别的指标。'})]}),s.jsxs(e,{title:"MFE（最大浮盈 / 最大有利偏移）",children:[s.jsx("p",{children:s.jsx("strong",{children:"Maximum Favorable Excursion - 最大有利偏移"})}),s.jsx("p",{className:"mt-2",children:"定义：单笔交易持仓期间，价格向有利方向移动的最大幅度（即最大浮盈）。"}),s.jsx("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mt-3",children:s.jsx("p",{className:"text-xs",children:"举例：您做多后，价格最高涨到了 +$500，最后平仓盈利 $300，MFE = $500（最大浮盈 $500）"})}),s.jsx("p",{className:"mt-3",children:"意义："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-1",children:[s.jsx("li",{children:"反映单笔交易中您曾经触及的最大浮盈"}),s.jsx("li",{children:"用于评估止盈策略效果"}),s.jsx("li",{children:"MFE - PnL = 动态回撤（利润回吐金额）"}),s.jsx("li",{children:"帮助优化出场时机"})]})]}),s.jsxs(e,{title:"R倍数 (R-Multiple)",children:[s.jsx("p",{children:s.jsx("strong",{children:"风险回报倍数"})}),s.jsx("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mt-3 font-mono",children:s.jsx("p",{className:"text-[#c9a227]",children:"R倍数 = 实际盈亏 / |MAE|"})}),s.jsx("p",{className:"mt-3",children:"解读："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-1",children:[s.jsx("li",{children:"R = 2：盈利是承担风险的 2 倍"}),s.jsx("li",{children:"R = 1：盈亏等于风险"}),s.jsx("li",{children:"R = 0.5：盈利只有风险的一半"}),s.jsx("li",{children:"R < 0：亏损交易"})]}),s.jsx(a,{type:"success",children:"追求高 R倍数交易是专业交易者的核心目标之一。平均 R倍数 > 1 意味着系统具有正期望值。"})]}),s.jsxs(e,{title:"利润留存率",children:[s.jsx("p",{children:s.jsx("strong",{children:"Profit Retention Rate"})}),s.jsx("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mt-3 font-mono",children:s.jsx("p",{className:"text-[#c9a227]",children:"利润留存率 = (MFE - max(0, PnL)) / MFE"})}),s.jsx("p",{className:"mt-3",children:"解读："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-1",children:[s.jsx("li",{children:"0%：完美止盈，在最高点平仓"}),s.jsx("li",{children:"50%：回吐了一半利润"}),s.jsx("li",{children:"100%：从盈利变成亏损"})]}),s.jsx(a,{type:"warning",children:"留存率持续偏高（>50%）说明止盈策略需要优化，考虑使用移动止盈或更早出场。"})]}),s.jsxs(e,{title:"期望值 (Expectancy)",children:[s.jsx("p",{children:s.jsx("strong",{children:"每笔交易的平均预期收益"})}),s.jsx("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mt-3 font-mono",children:s.jsx("p",{className:"text-[#c9a227]",children:"期望值 = (胜率 × 平均盈利) - (败率 × 平均亏损)"})}),s.jsx("p",{className:"mt-3",children:"解读："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-1",children:[s.jsx("li",{children:"期望值 > 0：系统长期盈利"}),s.jsx("li",{children:"期望值 = 0：长期盈亏平衡"}),s.jsx("li",{children:"期望值 < 0：系统长期亏损"})]}),s.jsx(a,{type:"info",children:"即使胜率只有 40%，只要平均盈利足够大，期望值仍可为正。反之，90% 胜率但盈亏比极低，期望值也可能为负。"})]}),s.jsxs(e,{title:"处置效应 (Disposition Effect)",children:[s.jsx("p",{children:s.jsx("strong",{children:"行为金融学概念"})}),s.jsx("p",{className:"mt-2",children:"定义：投资者倾向于过早卖出盈利仓位，过晚卖出亏损仓位。"}),s.jsxs("div",{className:"bg-[#0a0a0c] rounded-lg p-4 border border-[#1a1a1f] mt-3",children:[s.jsx("p",{className:"text-xs",children:"表现："}),s.jsxs("ul",{className:"list-disc list-inside space-y-1 mt-1 text-xs",children:[s.jsx("li",{children:"盈利单持仓时间短（急于落袋为安）"}),s.jsx("li",{children:"亏损单持仓时间长（不愿承认错误）"}),s.jsx("li",{children:"结果：截断利润，放大亏损"})]})]}),s.jsx(a,{type:"warning",children:"如果您的亏损单平均持仓时间明显长于盈利单，说明存在处置效应，需要改进出场纪律。"})]})]})});case"faq":return s.jsx(s.Fragment,{children:s.jsx(r,{icon:s.jsx(g,{}),title:"常见问题",children:s.jsx("div",{className:"bg-[#111114] rounded-xl border border-[#1a1a1f] p-6",children:E.map((c,m)=>s.jsx(C,{question:c.question,answer:c.answer,isOpen:n===m,onClick:()=>y(n===m?null:m)},m))})})});default:return null}};return s.jsxs("div",{className:"min-h-screen bg-[#0a0a0c]",children:[s.jsx("nav",{className:"fixed w-full z-50 bg-[#0d0d10]/95 backdrop-blur-xl border-b border-[#1a1a1f]",children:s.jsxs("div",{className:"max-w-6xl mx-auto px-6 py-4 flex justify-between items-center",children:[s.jsxs("div",{className:"flex items-center gap-4",children:[s.jsxs("button",{onClick:l,className:"flex items-center gap-2 text-[#888] hover:text-[#c9a227] transition-colors",children:[s.jsx(M,{}),s.jsx("span",{className:"text-sm",children:"返回首页"})]}),s.jsx("div",{className:"w-px h-5 bg-[#1a1a1f]"}),s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(h,{className:"text-[#c9a227]"}),s.jsx("span",{className:"text-sm font-semibold text-[#fff]",children:"帮助文档"})]})]}),s.jsx("button",{onClick:t,className:"text-sm font-semibold bg-[#c9a227] text-[#0a0a0c] px-5 py-2 rounded hover:bg-[#d4af37] transition-all",children:"免费开始"})]})}),s.jsx("div",{className:"pt-20 pb-16",children:s.jsxs("div",{className:"max-w-6xl mx-auto px-6",children:[s.jsxs("div",{className:"text-center py-12",children:[s.jsx("h1",{className:"text-3xl font-bold text-[#fff] mb-4",children:"TradeWhy.AI 帮助中心"}),s.jsx("p",{className:"text-[#666] max-w-xl mx-auto",children:"详细的使用文档和常见问题解答，帮助您快速上手"})]}),s.jsxs("div",{className:"grid lg:grid-cols-4 gap-8",children:[s.jsx("div",{className:"lg:col-span-1",children:s.jsx("div",{className:"sticky top-24 space-y-2",children:A.map(c=>s.jsx(R,{icon:c.icon,title:c.title,description:c.description,isActive:i===c.key,onClick:()=>x(c.key)},c.key))})}),s.jsx("div",{className:"lg:col-span-3",children:s.jsx("div",{className:"bg-[#111114] rounded-xl border border-[#1a1a1f] p-8",children:w()})})]})]})}),s.jsx("section",{className:"py-16 px-6 bg-[#0d0d10] border-t border-[#1a1a1f]",children:s.jsxs("div",{className:"max-w-3xl mx-auto text-center",children:[s.jsx("h2",{className:"text-2xl font-bold text-[#fff] mb-4",children:"准备好开始了吗？"}),s.jsx("p",{className:"text-[#666] mb-8",children:"免费注册，立即体验 AI 交易教练"}),s.jsxs("button",{onClick:t,className:"inline-flex items-center gap-2 bg-[#c9a227] text-[#0a0a0c] px-8 py-3 rounded-lg font-semibold hover:bg-[#d4af37] transition-all",children:["立即免费开始",s.jsx(I,{})]}),s.jsxs("div",{className:"mt-4 flex items-center justify-center gap-6 text-sm text-[#555]",children:[s.jsxs("span",{className:"flex items-center gap-1",children:[s.jsx(o,{className:"text-[#c9a227]"})," 免费使用"]}),s.jsxs("span",{className:"flex items-center gap-1",children:[s.jsx(o,{className:"text-[#c9a227]"})," 无需信用卡"]})]})]})}),s.jsx("footer",{className:"py-6 px-6 border-t border-[#1a1a1f]",children:s.jsxs("div",{className:"max-w-6xl mx-auto flex justify-between items-center",children:[s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx("img",{src:"/logo.svg",alt:"TradeWhy.AI",className:"h-5 object-contain"}),s.jsx("span",{className:"font-semibold text-[#fff] text-sm",children:"TradeWhy.AI"})]}),s.jsx("div",{className:"text-xs text-[#444]",children:"© 2026 TradeWhy.AI"})]})})]})};export{$ as default};
