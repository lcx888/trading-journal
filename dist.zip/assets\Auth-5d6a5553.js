import{j as e}from"./vendor-utils-4aeb5550.js";import{r as l}from"./vendor-react-fa9da516.js";import{v as _,s as S,l as D,k as H,m as J,n as Q}from"./index-b88b6955.js";import{Q as n,aH as F,a as A,B as v,$ as c,aI as I,ab as G,L as g,aJ as U,aK as X,V as r}from"./vendor-antd-01347ada.js";const ae=({onAuth:m,onBack:N,initialMode:P,resetToken:R})=>{const[T,i]=l.useState(!1),[t,u]=l.useState(P||"login"),[k,q]=l.useState(!1),[E,y]=l.useState(!1),[d]=n.useForm(),[a,x]=l.useState(1),[b,C]=l.useState(""),[h,w]=l.useState(""),[o,j]=l.useState(0);l.useEffect(()=>{if(o>0){const s=setTimeout(()=>j(o-1),1e3);return()=>clearTimeout(s)}},[o]);const O=async()=>{try{const s=await d.validateFields(["email"]);i(!0),await S(s.email),C(s.email),x(2),j(60),r.success("验证码已发送到您的邮箱")}catch(s){r.error(s.message||"发送失败")}finally{i(!1)}},z=async()=>{if(!h||h.length!==6){r.error("请输入6位验证码");return}try{i(!0),await _(b,h),x(3),r.success("验证成功，请设置密码")}catch(s){r.error(s.message||"验证失败")}finally{i(!1)}},W=async()=>{try{const s=await d.validateFields(["password","confirmPassword"]);i(!0);const p=await Q(b,s.password,h);r.success(p.message||"注册成功"),m==null||m(p)}catch(s){r.error(s.message||"注册失败")}finally{i(!1)}},L=async()=>{if(!(o>0))try{i(!0),await S(b),j(60),r.success("验证码已重新发送")}catch(s){r.error(s.message||"发送失败")}finally{i(!1)}},M=async()=>{try{const s=await d.validateFields();if(i(!0),t==="register"){if(a===1){await O();return}else if(a===2){await z();return}else if(a===3){await W();return}}else if(t==="login"){const p=await D(s.email,s.password,k);r.success("登录成功"),m==null||m(p)}else t==="forgot"?(await H(s.email),r.success("如果该邮箱已注册，重置链接已发送"),y(!0)):t==="reset"&&(await J(R,s.password),r.success("密码重置成功！"),u("login"),d.resetFields())}catch(s){r.error(s.message||"操作失败")}finally{i(!1)}},V=()=>{u(t==="forgot"||t==="reset"?"login":t==="login"?"register":"login"),y(!1),x(1),C(""),w(""),j(0),d.resetFields()},$=()=>{u("forgot"),y(!1),d.resetFields()},B=()=>{if(t==="register")switch(a){case 1:return"创建账号";case 2:return"验证邮箱";case 3:return"设置密码";default:return"创建账号"}switch(t){case"forgot":return"忘记密码";case"reset":return"重置密码";default:return"欢迎回来"}},K=()=>{if(t==="register")switch(a){case 1:return"输入邮箱获取验证码";case 2:return`验证码已发送至 ${b}`;case 3:return"设置你的登录密码";default:return"开始你的专业交易复盘之旅"}switch(t){case"forgot":return"输入你的邮箱，我们将发送重置链接";case"reset":return"设置你的新密码";default:return"输入你的凭据以访问账户"}},Y=()=>{if(t==="register")switch(a){case 1:return"发送验证码";case 2:return"验证";case 3:return"完成注册";default:return"下一步"}switch(t){case"forgot":return"发送重置链接";case"reset":return"重置密码";default:return"登录"}};return e.jsxs("div",{className:"min-h-screen flex",style:{background:"#0a0a0c"},children:[e.jsxs("div",{className:"hidden lg:flex lg:w-1/2 flex-col justify-between p-12 relative overflow-hidden",style:{background:"#0d0d10",borderRight:"1px solid rgba(255,255,255,0.05)"},children:[e.jsxs("div",{className:"absolute inset-0",children:[e.jsx("div",{className:"absolute top-20 left-20 w-72 h-72 rounded-full",style:{border:"1px solid rgba(234,179,8,0.1)"}}),e.jsx("div",{className:"absolute bottom-20 right-10 w-96 h-96 rounded-full",style:{border:"1px solid rgba(234,179,8,0.05)"}}),e.jsx("div",{className:"absolute top-1/2 left-1/3 w-48 h-48 rounded-full",style:{border:"1px solid rgba(255,255,255,0.03)"}}),e.jsx("div",{className:"absolute top-1/4 right-1/4 w-64 h-64 rounded-full blur-3xl",style:{background:"rgba(234,179,8,0.08)"}})]}),e.jsx("div",{className:"relative z-10",children:e.jsx("div",{className:"flex items-center gap-3 cursor-pointer",onClick:N,children:e.jsx("img",{src:"/logo.svg",alt:"TradeWhy.AI",className:"h-10 object-contain"})})}),e.jsxs("div",{className:"relative z-10 space-y-8",children:[e.jsxs("h1",{className:"text-5xl font-bold leading-tight text-white",children:["用 ",e.jsx("span",{style:{color:"#eab308"},children:"AI"})," 驱动",e.jsx("br",{}),"你的交易复盘"]}),e.jsx("p",{className:"text-lg max-w-md leading-relaxed",style:{color:"#9ca3af"},children:"自动识别情绪化操作，分析策略漏洞，助你构建稳定盈利的交易系统。"}),e.jsxs("div",{className:"flex gap-12 pt-8",children:[e.jsxs("div",{children:[e.jsx("div",{className:"text-3xl font-bold font-mono",style:{color:"#eab308"},children:"10K+"}),e.jsx("div",{className:"text-sm mt-1",style:{color:"#6b7280"},children:"活跃交易员"})]}),e.jsxs("div",{children:[e.jsx("div",{className:"text-3xl font-bold font-mono",style:{color:"#10b981"},children:"98%"}),e.jsx("div",{className:"text-sm mt-1",style:{color:"#6b7280"},children:"用户满意度"})]}),e.jsxs("div",{children:[e.jsx("div",{className:"text-3xl font-bold font-mono text-white",children:"24/7"}),e.jsx("div",{className:"text-sm mt-1",style:{color:"#6b7280"},children:"技术支持"})]})]})]}),e.jsx("div",{className:"relative z-10 text-sm",style:{color:"#6b7280"},children:"© 2026 TradeWhy.AI Inc. All rights reserved."})]}),e.jsxs("div",{className:"flex-1 flex flex-col justify-center px-8 lg:px-24",children:[e.jsx("div",{className:"lg:hidden mb-8",children:e.jsxs("button",{onClick:N,className:"flex items-center gap-2 transition-colors",style:{color:"#9ca3af"},children:[e.jsx(F,{}),e.jsx("span",{children:"返回首页"})]})}),e.jsx("div",{className:"lg:hidden flex items-center gap-2 mb-12",children:e.jsx("img",{src:"/logo.svg",alt:"TradeWhy.AI",className:"h-8 object-contain"})}),e.jsxs("div",{className:"w-full max-w-md mx-auto",children:[e.jsxs("div",{className:"mb-10",children:[e.jsx("h2",{className:"text-3xl font-bold mb-3 text-white",children:B()}),e.jsx("p",{style:{color:"#9ca3af"},children:K()})]}),t==="forgot"&&E?e.jsxs("div",{className:"text-center py-8",children:[e.jsx("div",{className:"w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",style:{background:"rgba(16,185,129,0.1)"},children:e.jsx(A,{className:"text-3xl",style:{color:"#10b981"}})}),e.jsx("h3",{className:"text-xl font-bold text-white mb-2",children:"邮件已发送"}),e.jsxs("p",{className:"mb-6",style:{color:"#9ca3af"},children:["如果该邮箱已注册，你将收到密码重置链接。",e.jsx("br",{}),"请检查你的收件箱和垃圾邮件文件夹。"]}),e.jsx(v,{type:"link",onClick:()=>u("login"),style:{color:"#eab308",fontWeight:500},children:"返回登录"})]}):e.jsxs(e.Fragment,{children:[e.jsxs(n,{form:d,layout:"vertical",className:"auth-form",children:[(t==="login"||t==="forgot")&&e.jsx(n.Item,{name:"email",label:e.jsx("span",{className:"auth-label",children:"邮箱地址"}),rules:[{required:!0,message:"请输入邮箱"},{type:"email",message:"请输入有效的邮箱地址"}],children:e.jsx(c,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(I,{})}),placeholder:"name@example.com",size:"large",className:"auth-input"})}),t==="register"&&a===1&&e.jsx(n.Item,{name:"email",label:e.jsx("span",{className:"auth-label",children:"邮箱地址"}),rules:[{required:!0,message:"请输入邮箱"},{type:"email",message:"请输入有效的邮箱地址"}],children:e.jsx(c,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(I,{})}),placeholder:"name@example.com",size:"large",className:"auth-input"})}),t==="register"&&a===2&&e.jsxs("div",{className:"space-y-4",children:[e.jsx("div",{className:"text-center mb-6",children:e.jsx("div",{className:"w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",style:{background:"rgba(234,179,8,0.1)"},children:e.jsx(G,{className:"text-3xl",style:{color:"#eab308"}})})}),e.jsxs("div",{children:[e.jsx("label",{className:"auth-label block mb-2",children:"验证码"}),e.jsx(c,{value:h,onChange:s=>w(s.target.value.replace(/\D/g,"").slice(0,6)),placeholder:"输入6位验证码",size:"large",maxLength:6,className:"auth-input",style:{textAlign:"center",letterSpacing:"8px",fontSize:"24px",fontFamily:"monospace"}})]}),e.jsx("div",{className:"text-center mt-4",children:e.jsx("button",{type:"button",onClick:L,disabled:o>0,className:"text-sm transition-colors",style:{color:o>0?"#6b7280":"#eab308"},children:o>0?`${o}秒后可重新发送`:"重新发送验证码"})})]}),t==="register"&&a===3&&e.jsxs(e.Fragment,{children:[e.jsx(n.Item,{name:"password",label:e.jsx("span",{className:"auth-label",children:"设置密码"}),rules:[{required:!0,message:"请输入密码"},{min:6,message:"密码至少 6 位"}],children:e.jsx(c.Password,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(g,{})}),placeholder:"至少 6 位字符",size:"large",className:"auth-input"})}),e.jsx(n.Item,{name:"confirmPassword",label:e.jsx("span",{className:"auth-label",children:"确认密码"}),dependencies:["password"],rules:[{required:!0,message:"请确认密码"},({getFieldValue:s})=>({validator(p,f){return!f||s("password")===f?Promise.resolve():Promise.reject(new Error("两次密码不一致"))}})],children:e.jsx(c.Password,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(g,{})}),placeholder:"再次输入密码",size:"large",className:"auth-input"})})]}),t==="login"&&e.jsx(n.Item,{name:"password",label:e.jsx("span",{className:"auth-label",children:"密码"}),rules:[{required:!0,message:"请输入密码"},{min:6,message:"密码至少 6 位"}],children:e.jsx(c.Password,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(g,{})}),placeholder:"输入你的密码",size:"large",className:"auth-input"})}),t==="reset"&&e.jsxs(e.Fragment,{children:[e.jsx(n.Item,{name:"password",label:e.jsx("span",{className:"auth-label",children:"新密码"}),rules:[{required:!0,message:"请输入新密码"},{min:6,message:"密码至少 6 位"}],children:e.jsx(c.Password,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(g,{})}),placeholder:"至少 6 位字符",size:"large",className:"auth-input"})}),e.jsx(n.Item,{name:"confirmPassword",label:e.jsx("span",{className:"auth-label",children:"确认密码"}),dependencies:["password"],rules:[{required:!0,message:"请确认密码"},({getFieldValue:s})=>({validator(p,f){return!f||s("password")===f?Promise.resolve():Promise.reject(new Error("两次密码不一致"))}})],children:e.jsx(c.Password,{prefix:e.jsx("div",{className:"auth-input-icon",children:e.jsx(g,{})}),placeholder:"再次输入密码",size:"large",className:"auth-input"})})]}),t==="login"&&e.jsxs("div",{className:"flex justify-between items-center mb-4",children:[e.jsx(U,{checked:k,onChange:s=>q(s.target.checked),style:{color:"#9ca3af"},children:e.jsx("span",{style:{color:"#9ca3af"},children:"记住登录 30 天"})}),e.jsx("button",{type:"button",onClick:$,className:"text-sm transition-colors hover:underline",style:{color:"#eab308"},children:"忘记密码？"})]}),t==="register"&&a>1&&e.jsxs(v,{block:!0,size:"large",onClick:()=>{a===2?(x(1),w("")):a===3&&x(2)},style:{height:48,background:"transparent",border:"2px solid rgba(255,255,255,0.1)",borderRadius:8,fontWeight:600,fontSize:15,color:"#9ca3af",marginTop:16},children:[e.jsx(F,{className:"mr-2"}),"返回上一步"]}),e.jsxs(v,{type:"primary",block:!0,size:"large",loading:T,onClick:t==="register"&&a===2?z:M,style:{height:48,background:"#eab308",border:"none",borderRadius:8,fontWeight:600,fontSize:15,color:"#0a0a0c",marginTop:16,boxShadow:"0 4px 20px rgba(234,179,8,0.3)"},children:[Y(),e.jsx(X,{className:"ml-2"})]})]}),e.jsxs("div",{className:"flex items-center gap-4 my-8",children:[e.jsx("div",{className:"flex-1 h-px",style:{background:"rgba(255,255,255,0.08)"}}),e.jsx("span",{className:"text-sm",style:{color:"#6b7280"},children:"或"}),e.jsx("div",{className:"flex-1 h-px",style:{background:"rgba(255,255,255,0.08)"}})]}),e.jsx("div",{className:"text-center",children:t==="forgot"||t==="reset"?e.jsx("button",{onClick:()=>u("login"),className:"font-medium hover:underline",style:{color:"#eab308"},children:"返回登录"}):t==="register"&&a>1?e.jsxs("span",{style:{color:"#6b7280",fontSize:14},children:["步骤 ",a,"/3"]}):e.jsxs(e.Fragment,{children:[e.jsx("span",{style:{color:"#9ca3af"},children:t==="login"?"还没有账号？":"已有账号？"}),e.jsx("button",{onClick:V,className:"ml-2 font-medium hover:underline",style:{color:"#eab308"},children:t==="login"?"免费注册":"立即登录"})]})}),t==="register"&&a===3&&e.jsxs("p",{className:"text-center text-xs mt-8 leading-relaxed",style:{color:"#6b7280"},children:['点击"完成注册"即表示你同意我们的',e.jsx("br",{}),e.jsx("a",{href:"#",style:{color:"#9ca3af"},className:"hover:underline",children:"服务条款"})," 和 ",e.jsx("a",{href:"#",style:{color:"#9ca3af"},className:"hover:underline",children:"隐私政策"})]})]})]})]}),e.jsx("style",{children:`
        /* 标签样式 */
        .auth-label {
          color: #ffffff;
          font-weight: 600;
          font-size: 13px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        /* 图标容器 */
        .auth-input-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-right: 8px;
          color: #6b7280;
          font-size: 16px;
          transition: all 0.2s ease;
        }
        
        /* 输入框容器 */
        .auth-input.ant-input-affix-wrapper,
        .auth-input.ant-input {
          background: #0d0d10 !important;
          border: 2px solid rgba(255,255,255,0.06) !important;
          border-radius: 12px !important;
          padding: 8px 12px !important;
          height: 56px !important;
          transition: all 0.2s ease !important;
        }
        
        .auth-input.ant-input-affix-wrapper:hover,
        .auth-input.ant-input:hover {
          border-color: rgba(234,179,8,0.3) !important;
          background: #0f0f12 !important;
        }
        
        .auth-input.ant-input-affix-wrapper:hover .auth-input-icon,
        .auth-input.ant-input:hover .auth-input-icon {
          color: #9ca3af;
        }
        
        .auth-input.ant-input-affix-wrapper-focused,
        .auth-input.ant-input:focus {
          border-color: #eab308 !important;
          box-shadow: none !important;
          background: #0f0f12 !important;
        }
        
        .auth-input.ant-input-affix-wrapper-focused .auth-input-icon {
          color: #eab308;
        }
        
        .auth-input.ant-input-affix-wrapper input,
        .auth-input.ant-input {
          background: transparent !important;
          color: #ffffff !important;
          font-size: 15px !important;
          font-weight: 500 !important;
          border: none !important;
          box-shadow: none !important;
          outline: none !important;
        }
        
        .auth-input.ant-input-affix-wrapper input::placeholder,
        .auth-input.ant-input::placeholder {
          color: #4b5563 !important;
          font-weight: 400 !important;
        }
        
        /* 密码显示/隐藏图标 */
        .auth-input .ant-input-password-icon {
          color: #6b7280 !important;
          font-size: 16px !important;
          padding: 8px;
          border-radius: 6px;
          transition: all 0.2s ease;
        }
        
        .auth-input .ant-input-password-icon:hover {
          color: #eab308 !important;
          background: rgba(234,179,8,0.1);
        }
        
        /* 复选框 */
        .ant-checkbox-inner {
          background: #0d0d10 !important;
          border: 2px solid rgba(255,255,255,0.1) !important;
          border-radius: 4px !important;
          width: 18px !important;
          height: 18px !important;
        }
        
        .ant-checkbox:hover .ant-checkbox-inner {
          border-color: rgba(234,179,8,0.5) !important;
        }
        
        .ant-checkbox-checked .ant-checkbox-inner {
          background: #eab308 !important;
          border-color: #eab308 !important;
        }
        
        .ant-checkbox-checked .ant-checkbox-inner::after {
          border-color: #0a0a0c !important;
          border-width: 2px !important;
        }
        
        /* 表单项间距 */
        .auth-form .ant-form-item {
          margin-bottom: 20px !important;
        }
        
        .auth-form .ant-form-item-label {
          padding-bottom: 8px !important;
        }
        
        /* 错误提示 */
        .ant-form-item-explain-error {
          color: #f43f5e !important;
          font-size: 12px !important;
          margin-top: 6px !important;
        }
        
        /* 主按钮 */
        .ant-btn-primary:hover {
          background: #facc15 !important;
          transform: translateY(-1px);
          box-shadow: 0 6px 24px rgba(234,179,8,0.4) !important;
        }
        
        .ant-btn-primary:active {
          transform: translateY(0);
        }
        
        /* 错误状态输入框 */
        .ant-form-item-has-error .auth-input.ant-input-affix-wrapper,
        .ant-form-item-has-error .auth-input.ant-input {
          border-color: #f43f5e !important;
        }
        
        .ant-form-item-has-error .auth-input-icon {
          color: #f43f5e !important;
        }
      `})]})};export{ae as default};
