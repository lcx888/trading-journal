import{j as e,u as dt,w as gr}from"./vendor-utils-4aeb5550.js";import{r as N,c as yr}from"./vendor-react-fa9da516.js";import{Q as ne,V as ee,T as I,B as te,W as At,X as fr,K as hr,N as br,Y as vr,Z as jr,_ as wr,n as It,l as ve,$ as tt,z as kr,a0 as Sr,D as ct,a1 as $t,b as ce,a2 as rt,M as Ot,a3 as Nr,a4 as Ye,a5 as Mr,a6 as Cr,P as Tr,x as zr,a7 as Ce,a8 as Bt,a9 as Lr,aa as Er,t as Fr,ab as Rr,ac as Pr,O as Dr,ad as Qt,ae as qt,o as Ar,af as Ir,ag as $r,ah as Or}from"./vendor-antd-01347ada.js";import{S as pe}from"./index-b88b6955.js";const Br=(i,p)=>{const x=new Date(i.openTime).getTime(),n=new Date(i.closeTime).getTime(),m=new Date(p.openTime).getTime(),g=new Date(p.closeTime).getTime();return x>=m&&x<=g||m>=x&&m<=n};class Qr{constructor(p){this.parent=Array.from({length:p},(x,n)=>n),this.rank=Array(p).fill(0)}find(p){return this.parent[p]!==p&&(this.parent[p]=this.find(this.parent[p])),this.parent[p]}union(p,x){const n=this.find(p),m=this.find(x);n!==m&&(this.rank[n]<this.rank[m]?this.parent[n]=m:this.rank[n]>this.rank[m]?this.parent[m]=n:(this.parent[m]=n,this.rank[n]++))}}const qr=i=>{if(!i||i.length===0)return[];const p={};i.forEach((n,m)=>{const g=`${n.instrumentCode}_${n.direction}`;p[g]||(p[g]=[]),p[g].push({trade:n,idx:m})});const x=[];return Object.values(p).forEach(n=>{if(n.length<2)return;const m=new Qr(n.length);for(let M=0;M<n.length;M++)for(let u=M+1;u<n.length;u++)Br(n[M].trade,n[u].trade)&&m.union(M,u);const g={};for(let M=0;M<n.length;M++){const u=m.find(M);g[u]||(g[u]=[]),g[u].push(n[M].trade)}Object.values(g).forEach(M=>{M.length>1&&x.push(M)})}),x},Wr=(i,p=[])=>{if(!i||i.length===0)return null;const x=[...i].sort((T,Q)=>new Date(T.openTime)-new Date(Q.openTime)),n=x[0],m=x[x.length-1],g=Math.min(...i.map(T=>new Date(T.openTime).getTime())),M=Math.max(...i.map(T=>new Date(T.closeTime).getTime())),u=i.reduce((T,Q)=>T+Math.abs(Q.openQuantity||1),0),P=i.reduce((T,Q)=>{const H=Math.abs(Q.openQuantity||1);return T+Q.openPrice*H},0)/u,D=i.reduce((T,Q)=>{const H=Math.abs(Q.openQuantity||1);return T+Q.closePrice*H},0)/u,E=i.reduce((T,Q)=>T+(Q.pnl||0),0),j=Math.floor((M-g)/1e3),$=T=>{const Q={GC:10,ES:12.5,NQ:5,RTY:5,CL:10,SI:25,YM:5,ZB:31.25,ZN:15.625,"6E":12.5,M2K:.5,MES:1.25,MNQ:.5,MGC:1},H=p.find(C=>C.code===T);return(H==null?void 0:H.tickValue)||Q[T]||5};let re=0,ie=0;i.forEach(T=>{var ae,J;const Q=T.mae??((ae=T.jigsawData)==null?void 0:ae.mae),H=T.mfe??((J=T.jigsawData)==null?void 0:J.mfe),C=$(T.instrumentCode),ue=Math.abs(T.openQuantity||1);Q!=null&&(re+=Math.abs(Q)*C*ue),H!=null&&(ie+=Math.abs(H)*C*ue)});const Se=Gr(i),me=n.openPrice,R=n.direction==="LONG"?me-P:P-me,_=m.closePrice,v=n.direction==="LONG"?D-_:_-D;return{instrumentCode:n.instrumentCode,direction:n.direction,tradeCount:i.length,trades:x,firstOpenTime:new Date(g),lastCloseTime:new Date(M),totalDuration:j,totalQuantity:u,maxConcurrentQty:Se,avgQuantity:u/i.length,weightedOpenPrice:P,weightedClosePrice:D,firstEntryPrice:me,lastExitPrice:_,totalPnL:E,avgPnL:E/i.length,estimatedMAE:re,estimatedMFE:ie,riskRewardRatio:re>0?E/re:null,profitCaptureRate:ie>0?Math.max(0,E)/ie*100:null,entryImprovement:R,entryStrategy:R>0?"improved":R<0?"worsened":"neutral",exitImprovement:v,exitStrategy:v>0?"improved":v<0?"worsened":"neutral"}},Gr=i=>{const p=[];i.forEach(m=>{const g=Math.abs(m.openQuantity||1);p.push({time:new Date(m.openTime).getTime(),delta:g}),p.push({time:new Date(m.closeTime).getTime(),delta:-g})}),p.sort((m,g)=>m.time-g.time);let x=0,n=0;return p.forEach(m=>{x+=m.delta,x>n&&(n=x)}),n},Hr=(i,p=[])=>{if(!i||i.length===0)return[];const x=qr(i),n=new Map,m=new Map;x.forEach((P,D)=>{const E=`merge_${D}`,j=Wr(P,p);m.set(E,j),P.forEach($=>{n.set($.id,E)})});const g=[],M=new Set;return[...i].sort((P,D)=>new Date(D.openTime)-new Date(P.openTime)).forEach(P=>{const D=n.get(P.id);if(D){if(!M.has(D)){M.add(D);const E=m.get(D);g.push({id:D,isMergedGroup:!0,mergeStats:E,childTrades:E.trades,openTime:E.firstOpenTime,closeTime:E.lastCloseTime,instrumentCode:E.instrumentCode,direction:E.direction,openQuantity:E.totalQuantity,pnl:E.totalPnL,holdingSeconds:E.totalDuration})}}else g.push({...P,isMergedGroup:!1})}),g.sort((P,D)=>new Date(D.openTime)-new Date(P.openTime)),g},{RangePicker:_r}=Dr,{TextArea:Ke}=tt,Xe=i=>{if(!i||i===0)return"0s";const p=Math.floor(i/3600),x=Math.floor(i%3600/60),n=i%60;return p>0?`${p}h ${x}m`:x>0?`${x}m ${n}s`:`${n}s`},Vr={GC:10,ES:12.5,NQ:5,RTY:5,CL:10,SI:25,YM:5,ZB:31.25,ZN:15.625,"6E":12.5,M2K:.5,MES:1.25,MNQ:.5,MGC:1},_t=(i,p)=>{const x=p.find(n=>n.code===i);return x!=null&&x.tickValue?x.tickValue:Vr[i]||5},L=(i,p,x,n)=>{if(i==null)return null;const m=_t(p,n);return i*m*Math.abs(x||1)},Te=(i,p)=>{const x=i.instrumentCode||i.instrument||i.symbol,n=p.find(M=>{var u;return M.code===x||((u=M.code)==null?void 0:u.toUpperCase())===(x==null?void 0:x.toUpperCase())}),m=(n==null?void 0:n.feeRate)||0,g=Math.abs(i.openQuantity||i.quantity||1);return m*g*2},ze=(i,p)=>!i||i<=0?null:Math.max(0,p)/i*100,Wt=(i,p,x)=>{if(!i||i===0)return null;const n=Math.abs(i);return x<0?Math.abs(x)===0?null:n/Math.abs(x):!p||p===0?null:n/p},Ze=(i,p,x)=>{if(!i||i===0)return null;const n=Math.abs(i);let m=1;n>=800?m=5:n>=400?m=4:n>=200?m=3:n>=100&&(m=2);const g=x>300?Math.min((x-300)/1200,1):0,M=p<0&&n>Math.abs(p)*1.5?.5:0;return Math.min(5,m+g+M)},Gt=(i,p)=>!i||!p||p===0?null:i/Math.abs(p),Le=(i,p)=>!p||p===0?null:i/Math.abs(p),Ue=(i,p,x)=>{const{pnl:n}=i,m=Math.abs(p||0),g=Math.abs(x||0),M=Math.abs(n||0);return n>0?p&&x&&m<n*.3&&n>=g*.7?[{type:"perfect",label:"完美",color:"var(--color-profit)"}]:p&&m>n?[{type:"roller",label:"扛赢",color:"var(--text-secondary)"}]:x&&n<g*.3&&g>50?[{type:"earlyExit",label:"跑早",color:"var(--text-secondary)"}]:[]:n<0?x&&g<M*.2?[{type:"badEntry",label:"方向错",color:"var(--color-loss)"}]:x&&g>M*.5?[{type:"greed",label:"浮盈亏",color:"var(--color-loss)"}]:p&&M>=m*.8&&m>100?[{type:"badExit",label:"扛亏",color:"var(--color-loss)"}]:p&&M>=m*.9&&m<=150?[{type:"goodStop",label:"止损好",color:"var(--text-secondary)"}]:[]:[]},et=(i,p,x)=>{let n=0;const{pnl:m,fills:g,openQuantity:M}=i,u=Math.abs(M||1),P=Math.abs(p||0),D=Math.abs(x||0),E=Math.abs(m||0);if(m>0?n+=40:m===0?n+=20:n+=Math.max(0,20-E/100*5),p)if(m>0){const j=P/Math.max(m,1);j<.5?n+=30:j<1?n+=25:j<2?n+=15:n+=5}else{const j=E/Math.max(P,1);j<.5?n+=25:j<.8?n+=15:n+=5}else n+=15;if(x&&m>0){const j=m/Math.max(D,1);j>=.8?n+=20:j>=.5?n+=15:j>=.3?n+=10:n+=5}else m<=0?n+=5:n+=10;if(g&&u){const j=g/u;j<=1.5?n+=10:j<=3?n+=7:n+=3}else n+=7;return n>=85?{grade:"A",score:n,label:"优秀",color:"var(--color-profit)"}:n>=70?{grade:"B",score:n,label:"良好",color:"var(--color-profit)"}:n>=55?{grade:"C",score:n,label:"一般",color:"var(--text-secondary)"}:n>=40?{grade:"D",score:n,label:"较差",color:"var(--color-loss)"}:{grade:"F",score:n,label:"很差",color:"var(--color-loss)"}},Ht=({mae:i,mfe:p,pnl:x,maeUSD:n,mfeUSD:m})=>{if(!i&&!p)return null;const g=Math.abs(n||0),M=Math.abs(m||0),u=g+M;if(u===0)return null;const P=g/u*100,D=P,E=100-P;let j=P;if(x>=0&&M>0){const $=Math.min(x/M,1);j=P+$*E}else if(x<0&&g>0){const $=Math.min(Math.abs(x)/g,1);j=P-$*D}return j=Math.max(2,Math.min(98,j)),e.jsxs("div",{className:"w-full",children:[e.jsxs("div",{className:"relative h-4 rounded-sm overflow-hidden",style:{background:"var(--bg-tertiary)"},children:[e.jsx("div",{className:"absolute left-0 top-0 h-full",style:{width:`${D}%`,background:"linear-gradient(90deg, rgba(244,63,94,0.6) 0%, rgba(244,63,94,0.3) 100%)"}}),e.jsx("div",{className:"absolute right-0 top-0 h-full",style:{width:`${E}%`,background:"linear-gradient(90deg, rgba(16,185,129,0.3) 0%, rgba(16,185,129,0.6) 100%)"}}),e.jsx("div",{className:"absolute top-0 h-full w-0.5",style:{left:`${D}%`,background:"var(--text-primary)",opacity:.5}}),e.jsx("div",{className:"absolute top-0 h-full w-1",style:{left:`${j}%`,transform:"translateX(-50%)",background:x>=0?"var(--color-profit)":"var(--color-loss)",borderRadius:2}})]}),e.jsxs("div",{className:"flex justify-between mt-1 text-[10px]",children:[e.jsxs("span",{style:{color:"var(--color-loss)"},children:["-$",g.toFixed(0)]}),e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"入场"}),e.jsxs("span",{style:{color:"var(--color-profit)"},children:["+$",M.toFixed(0)]})]})]})},Jr=({score:i})=>{if(i===null)return e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"});const p=n=>n>=4?"var(--color-loss)":n>=3?"#f97316":n>=2?"#eab308":"var(--color-profit)",x=n=>n>=4.5?"极高":n>=3.5?"高":n>=2.5?"中等":n>=1.5?"低":"极低";return e.jsx(I,{title:`心理压力等级: ${(i??0).toFixed(1)}/5`,children:e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsx("div",{className:"flex gap-0.5",children:[1,2,3,4,5].map(n=>e.jsx("div",{className:"w-1.5 h-3 rounded-sm",style:{background:n<=Math.round(i)?p(i):"var(--bg-tertiary)"}},n))}),e.jsx("span",{className:"text-xs font-medium",style:{color:p(i)},children:x(i)})]})})},Vt="tradeListTableConfig",pt=()=>({hiddenColumns:[],rowHeight:"middle"}),Yr=()=>{try{const i=localStorage.getItem(Vt);return i?{...pt(),...JSON.parse(i)}:pt()}catch{return pt()}},Kr=i=>{localStorage.setItem(Vt,JSON.stringify(i))},ke={首仓:{title:"开仓复盘",questions:[{key:"entrySignal",label:"入场信号",placeholder:"是什么信号触发了这次入场？"},{key:"marketContext",label:"市场背景",placeholder:"当时的市场环境是怎样的？"}]},加仓:{title:"加仓复盘",questions:[{key:"reason",label:"加仓原因",placeholder:"为什么选择在这个位置加仓？"}]},减仓:{title:"减仓复盘",questions:[{key:"reason",label:"减仓原因",placeholder:"为什么选择减仓而不是持有？"}]},平仓:{title:"平仓复盘",questions:[{key:"exitSignal",label:"平仓信号",placeholder:"是什么信号触发了平仓？"}]}},xt=i=>`trade_review_${i}`,Xr=i=>{try{const p=localStorage.getItem(xt(i));return p?JSON.parse(p):{}}catch{return{}}},Zr=(i,p)=>{localStorage.setItem(xt(i),JSON.stringify(p))},Ur=i=>{try{const p=xt(i),x=localStorage.getItem(p);if(!x)return!1;const n=JSON.parse(x);return Object.values(n).some(m=>!m||typeof m!="object"?!1:Object.values(m).some(g=>g&&String(g).trim()!==""))}catch{return!1}},ea=i=>i?["notes","entryReason","stopLossReason","takeProfitReason","expectedTrend"].some(x=>i[x]&&String(i[x]).trim()!==""):!1,ta=({trades:i,overallDirection:p,dayjs:x,onStartReview:n,reviewNotes:m})=>{var Z,Fe;const[g,M]=N.useState(1),[u,P]=N.useState(null),D=N.useRef(null),E=N.useRef(null);N.useEffect(()=>{const c=E.current;if(!c)return;const S=K=>{K.preventDefault();const le=K.deltaY>0?-.1:.1;M(F=>Math.max(.5,Math.min(3,F+le)))};return c.addEventListener("wheel",S,{passive:!1}),()=>{c.removeEventListener("wheel",S)}},[]);const j=[];i.forEach(c=>{const S=Math.abs(c.openQuantity||1);j.push({time:new Date(c.openTime).getTime(),type:"open",qty:S,price:c.openPrice||0,trade:c}),j.push({time:new Date(c.closeTime).getTime(),type:"close",qty:S,price:c.closePrice||0,trade:c})}),j.sort((c,S)=>c.time-S.time);const $=[];let re=0,ie=0;j.forEach(c=>{var Me;const S=re,K=ie;c.type==="open"?(ie=S===0?c.price:(S*ie+c.qty*c.price)/(S+c.qty),re+=c.qty):re-=c.qty;let le,F,se=!1;const X=(c.price-K)*p,Y=i[0],be=Y&&Y.openQuantity&&Y.closePrice-Y.openPrice!==0?Math.abs(Y.pnl/((Y.closePrice-Y.openPrice)*Y.openQuantity)):1,de=S>0?(c.price-K)*S*p*be:0;c.type==="open"?(le=S===0?"首仓":"加仓",se=S>0&&X>0,F=S===0?"var(--color-brand)":se?"#22c55e":"#ef4444"):(le=re===0?"平仓":"减仓",se=X>0,F=se?"#22c55e":"#ef4444"),$.push({time:c.time,position:re,prevPosition:S,avgPrice:ie,price:c.price,label:le,color:F,isProfitAction:se,qty:c.qty,type:c.type,floatingPnl:de,displayPnl:c.type==="close"?((Me=c.trade)==null?void 0:Me.pnl)||(c.price-K)*c.qty*p*be:de})});const Se=500,me=1200,R=Se*g,_={top:140,right:100,bottom:140,left:80},v=me-_.left-_.right,T=R-_.top-_.bottom,Q=$.map(c=>c.price),H=$.filter(c=>c.avgPrice>0).map(c=>c.avgPrice),C=Math.min(...Q,...H),ue=Math.max(...Q,...H),ae=(ue-C)*.4||.1,J=C-ae,Ne=ue+ae,he=Ne-J||1,ge=((Z=$[0])==null?void 0:Z.time)||0,Oe=(((Fe=$[$.length-1])==null?void 0:Fe.time)||1)-ge||1,Ee=Math.max(...$.map(c=>c.position),1),V=c=>_.left+(c-ge)/Oe*v,ye=c=>_.top+T-(c-J)/he*T;return e.jsxs("div",{ref:D,className:"modern-chart-container",children:[e.jsxs("div",{className:"modern-chart-header",children:[e.jsxs("div",{className:"header-info",children:[e.jsx("div",{className:"direction-tag",style:{color:p===1?"#22c55e":"#ef4444"},children:p===1?"做多":"做空"}),e.jsxs("div",{className:"stats-group",children:[e.jsxs("div",{className:"stat",children:[e.jsx("span",{className:"label",children:"总盈亏"}),e.jsx("span",{className:"value",style:{color:i.reduce((c,S)=>c+(S.pnl||0),0)>=0?"#22c55e":"#ef4444"},children:i.reduce((c,S)=>c+(S.pnl||0),0).toFixed(2)})]}),e.jsxs("div",{className:"stat",children:[e.jsx("span",{className:"label",children:"交易数"}),e.jsx("span",{className:"value",children:i.length})]})]}),e.jsxs("div",{style:{marginLeft:24,padding:"4px 12px",background:"var(--color-brand)15",border:"1px solid var(--color-brand)30",borderRadius:20,display:"flex",alignItems:"center",gap:8,animation:"pulse-soft 2s infinite"},children:[e.jsx(rt,{style:{color:"var(--color-brand)",fontSize:12}}),e.jsx("span",{style:{fontSize:11,color:"var(--color-brand)",fontWeight:600},children:"点击节点标签记录复盘逻辑"})]})]}),e.jsxs("div",{className:"header-controls",children:[e.jsxs("div",{className:"legend",children:[e.jsxs("div",{className:"item",children:[e.jsx("span",{className:"dot",style:{background:"#22c55e"}})," 盈利操作"]}),e.jsxs("div",{className:"item",children:[e.jsx("span",{className:"dot",style:{background:"#ef4444"}})," 亏损操作"]}),e.jsxs("div",{className:"item",children:[e.jsx("span",{className:"line",style:{borderTop:"1px dashed var(--text-tertiary)"}})," 均价线"]})]}),e.jsx("button",{className:"reset-btn",onClick:()=>M(1),children:"RESET"})]})]}),e.jsx("div",{className:"modern-svg-wrapper",ref:E,children:e.jsxs("svg",{width:"100%",height:R,viewBox:`0 0 ${me} ${R}`,className:"modern-svg",children:[e.jsx("defs",{children:e.jsxs("filter",{id:"softGlow",x:"-20%",y:"-20%",width:"140%",height:"140%",children:[e.jsx("feGaussianBlur",{stdDeviation:"2",result:"blur"}),e.jsx("feComposite",{in:"SourceGraphic",in2:"blur",operator:"over"})]})}),e.jsx("g",{className:"grid",children:[J,C,(C+ue)/2,ue,Ne].map((c,S)=>e.jsxs("g",{children:[e.jsx("line",{x1:_.left,y1:ye(c),x2:me-_.right,y2:ye(c),stroke:"var(--border-primary)",strokeWidth:"0.5",strokeDasharray:"4,4",opacity:"0.3"}),e.jsx("text",{x:_.left-10,y:ye(c)+4,textAnchor:"end",fontSize:"10",fill:"var(--text-tertiary)",fontFamily:"monospace",children:c.toFixed(2)})]},S))}),e.jsx("path",{d:$.filter(c=>c.avgPrice>0).map((c,S)=>`${S===0?"M":"L"} ${V(c.time)} ${ye(c.avgPrice)}`).join(" "),fill:"none",stroke:"var(--text-tertiary)",strokeWidth:"1",strokeDasharray:"5,5",opacity:"0.6"}),$.length>1&&$.slice(0,-1).map((c,S)=>{const K=$[S+1];return e.jsx("line",{x1:V(c.time),y1:ye(c.price),x2:V(K.time),y2:ye(K.price),stroke:"var(--text-primary)",strokeWidth:Math.max(1.5,c.position/Ee*6),strokeLinecap:"round"},S)}),$.map((c,S)=>{const K=u===S,F=[-120,-60,60,120][S%4];let se=0;if(S>0){const de=V($[S-1].time),Me=V(c.time);Math.abs(Me-de)<40&&(se=S%2===0?-30:30)}const X=V(c.time),Y=ye(c.price),be=X+se;return e.jsxs("g",{onMouseEnter:()=>P(S),onMouseLeave:()=>P(null),style:{cursor:"pointer"},children:[K&&e.jsx("line",{x1:X,y1:_.top,x2:X,y2:R-_.bottom,stroke:"var(--color-brand)",strokeWidth:"0.5",strokeDasharray:"2,2"}),e.jsx("path",{d:`M ${X} ${Y} L ${be} ${Y+(F>0?F-25:F+25)}`,fill:"none",stroke:c.color,strokeWidth:"0.5",opacity:"0.4"}),e.jsx("circle",{cx:X,cy:Y,r:K?6:4,fill:c.color,filter:"url(#softGlow)"}),e.jsxs("g",{transform:`translate(${be}, ${Y+F})`,children:[e.jsx("rect",{x:"-50",y:"-22",width:"100",height:"75",fill:"var(--bg-primary)",fillOpacity:"0.9",rx:"6",stroke:"var(--border-primary)",strokeWidth:"0.5"}),e.jsxs("g",{onClick:de=>{de.stopPropagation(),n&&n(S,c)},style:{cursor:"pointer"},className:"review-label-btn",children:[e.jsx("rect",{x:"-32",y:"-18",width:"64",height:"22",rx:"4",fill:m[S]?`${c.color}30`:"transparent",stroke:m[S]?c.color:"transparent",strokeWidth:"1"}),e.jsx("text",{textAnchor:"middle",fontSize:"12",fontWeight:"800",fill:c.color,dy:"-3",children:c.label}),m[S]&&e.jsx("circle",{cx:"28",cy:"-8",r:"4",fill:"var(--color-brand)"})]}),e.jsxs("text",{textAnchor:"middle",fontSize:"11",fontWeight:"600",fill:"var(--text-primary)",dy:"12",children:[c.type==="open"?"+":"-",c.qty,"手 @ ",c.price.toFixed(2)]}),e.jsxs("text",{textAnchor:"middle",fontSize:"10",fill:"var(--text-tertiary)",dy:"26",children:["持仓: ",c.position.toFixed(1),"手"]}),c.displayPnl!==0&&e.jsxs("text",{textAnchor:"middle",fontSize:"12",fontWeight:"900",fill:c.displayPnl>=0?"#22c55e":"#ef4444",dy:"42",children:[c.displayPnl>=0?"盈":"亏"," ",c.displayPnl>=0?"+":"",c.displayPnl.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2})]})]}),K&&e.jsx("g",{transform:`translate(${V(c.time)}, ${R-_.bottom+15})`,children:e.jsx("text",{textAnchor:"middle",fontSize:"10",fill:"var(--text-secondary)",fontFamily:"monospace",children:x(c.time).format("HH:mm:ss")})})]},S)})]})})]})},na=({activeRecordId:i="all"})=>{var bt,vt,jt,wt,kt,St,Nt,Mt,Ct,Tt,zt,Lt;const[p,x]=N.useState(!0),[n,m]=N.useState([]),[g,M]=N.useState([]),[u,P]=N.useState([]),[D,E]=N.useState([]),[j,$]=N.useState(!1),[re,ie]=N.useState(""),[Se,me]=N.useState(!1),[R,_]=N.useState(window.innerWidth<768);N.useEffect(()=>{const r=()=>_(window.innerWidth<768);return window.addEventListener("resize",r),()=>window.removeEventListener("resize",r)},[]);const[v,T]=N.useState({instrument:"ALL",direction:"ALL",result:"ALL",session:"ALL",strategy:"ALL",dateRange:null,keyword:"",source:"ALL",rating:"ALL"}),[Q,H]=N.useState(!1),[C,ue]=N.useState(null),[ae]=ne.useForm(),[J,Ne]=N.useState({tradeId:null,field:null,trade:null}),[he,ge]=N.useState(null),[G,Oe]=N.useState("tick"),Ee=N.useRef(null),[V,ye]=N.useState(!0),[Z,Fe]=N.useState(null),[c,S]=N.useState(!1),[K,le]=N.useState(!1),[F,se]=N.useState(null),[X,Y]=N.useState({}),[be,de]=N.useState({}),[Me,at]=N.useState(!1),[Be]=ne.useForm(),[xe,Jt]=N.useState(Yr),[Yt,mt]=N.useState(!1),[oe,ut]=N.useState(!1),gt=N.useRef(null),Qe=N.useRef(!1),st=N.useRef({x:0,scrollLeft:0}),Kt=[{key:"openTime",label:"时间"},{key:"instrumentCode",label:"品种"},{key:"direction",label:"方向"},{key:"quantity",label:"数量"},{key:"prices",label:"价格"},{key:"pnl",label:"盈亏"},{key:"fee",label:"手续费"},{key:"feeRatio",label:"费率"},{key:"marketSession",label:"时段"},{key:"duration",label:"时长"},{key:"mae",label:"最大浮亏",jigsaw:!0},{key:"mfe",label:"最大浮盈",jigsaw:!0},{key:"fills",label:"成交",jigsaw:!0},{key:"riskReward",label:"风险回报",jigsaw:!0},{key:"profitCapture",label:"捕获率",jigsaw:!0},{key:"stressScore",label:"压力",jigsaw:!0},{key:"diagnosis",label:"诊断",jigsaw:!0},{key:"tradeRange",label:"波动区间",jigsaw:!0},{key:"rating",label:"评级",jigsaw:!0},{key:"strategyTags",label:"策略"}],ot=r=>{const t={...xe,...r};Jt(t),Kr(t)},Xt=r=>{const t=xe.hiddenColumns.includes(r)?xe.hiddenColumns.filter(s=>s!==r):[...xe.hiddenColumns,r];ot({hiddenColumns:t})},Zt={compact:{size:"small",padding:"4px 12px"},middle:{size:"middle",padding:"8px 16px"},large:{size:"large",padding:"12px 20px"}};N.useEffect(()=>{let r=()=>{};const t=setTimeout(()=>{const s=gt.current;if(!s)return;const a=()=>s.querySelector(".ant-table-body")||s.querySelector(".ant-table-content")||s.querySelector(".ant-table"),o=h=>{const y=a();y&&(h.target.closest("button, a, .ant-dropdown-trigger, .ant-btn, .ant-input-number")||(Qe.current=!0,st.current={x:h.clientX,scrollLeft:y.scrollLeft},s.style.cursor="grabbing",s.style.userSelect="none",h.preventDefault()))},l=h=>{if(!Qe.current)return;const y=a();if(!y)return;const b=h.clientX-st.current.x;y.scrollLeft=st.current.scrollLeft-b},d=()=>{Qe.current&&(s.style.cursor="",s.style.userSelect="",Qe.current=!1)};s.addEventListener("mousedown",o),document.addEventListener("mousemove",l),document.addEventListener("mouseup",d),r=()=>{s.removeEventListener("mousedown",o),document.removeEventListener("mousemove",l),document.removeEventListener("mouseup",d)}},50);return()=>{clearTimeout(t),r()}},[g,oe]),N.useEffect(()=>{qe()},[i]),N.useEffect(()=>{Ut()},[n,v,V,u]),N.useEffect(()=>{const r=pe.getTraderName();ie(r)},[]),N.useEffect(()=>{const r=t=>{t.key==="Escape"&&oe&&ut(!1)};return document.addEventListener("keydown",r),()=>document.removeEventListener("keydown",r)},[oe]);const qe=async()=>{x(!0);try{const[r,t,s]=await Promise.all([pe.getAllTrades(),pe.getInstruments(),pe.getAllStrategies()]);E(s);let a=r;i!=="all"&&(a=r.filter(l=>l.recordId===i)),a.sort((l,d)=>new Date(d.openTime)-new Date(l.openTime)),m(a),P(t);const o=a.some(l=>l.source==="jigsaw"||l.jigsawData||l.mae!==void 0||l.mfe!==void 0);$(o)}catch{ee.error("加载数据失败")}finally{x(!1)}},Ut=()=>{let r=[...n];if(v.instrument!=="ALL"&&(r=r.filter(t=>t.instrumentCode===v.instrument)),v.direction!=="ALL"&&(r=r.filter(t=>t.direction===v.direction)),v.result!=="ALL"&&(v.result==="WIN"?r=r.filter(t=>t.pnl>0):v.result==="LOSS"&&(r=r.filter(t=>t.pnl<0))),v.session!=="ALL"&&(r=r.filter(t=>t.marketSession===v.session)),v.dateRange&&v.dateRange[0]&&v.dateRange[1]){const t=v.dateRange[0].startOf("day").toDate(),s=v.dateRange[1].endOf("day").toDate();r=r.filter(a=>{const o=new Date(a.openTime);return o>=t&&o<=s})}if(v.keyword){const t=v.keyword.toLowerCase();r=r.filter(s=>{var a,o,l,d,h;return((a=s.instrumentCode)==null?void 0:a.toLowerCase().includes(t))||((o=s.entryReason)==null?void 0:o.toLowerCase().includes(t))||((l=s.stopLossReason)==null?void 0:l.toLowerCase().includes(t))||((d=s.takeProfitReason)==null?void 0:d.toLowerCase().includes(t))||((h=s.notes)==null?void 0:h.toLowerCase().includes(t))})}if(v.strategy!=="ALL"&&(v.strategy==="NONE"?r=r.filter(t=>!t.strategyIds||t.strategyIds.length===0):r=r.filter(t=>t.strategyIds&&t.strategyIds.includes(v.strategy))),v.source!=="ALL"&&(r=r.filter(t=>(t.source||(t.jigsawData?"jigsaw":"atas"))===v.source)),v.rating!=="ALL"&&(r=r.filter(t=>{var h,y;const s=t.mae??((h=t.jigsawData)==null?void 0:h.mae),a=t.mfe??((y=t.jigsawData)==null?void 0:y.mfe),o=s!==void 0?L(s,t.instrumentCode,t.openQuantity,u):null,l=a!==void 0?L(a,t.instrumentCode,t.openQuantity,u):null;return et(t,o,l).grade===v.rating})),V){const t=Hr(r,u);M(t)}else M(r.map(t=>({...t,isMergedGroup:!1})))},er=r=>{r.isMergedGroup&&r.mergeStats&&(Fe(r),S(!0),Y(Xr(r.id||"default")))},tr=()=>{S(!1),Fe(null),le(!1),se(null)},nt=(r,t)=>{const s=(Z==null?void 0:Z.id)||"default";se({index:r,point:t,groupId:s}),de(X[r]||{}),le(!0)},rr=()=>{if(F!==null){const r={...X,[F.index]:be};Y(r),Zr(F.groupId,r),le(!1),se(null),de({}),ee.success("复盘笔记已保存")}},ar=()=>{le(!1),se(null),de({})},sr=r=>D.find(t=>t.id===r),or=async(r,t)=>{try{await pe.addStrategyToTrade(r,t),m(s=>s.map(a=>a.id===r?{...a,strategyIds:[...a.strategyIds||[],t]}:a)),ee.success("标签已添加")}catch{ee.error("操作失败")}},nr=async(r,t)=>{try{await pe.removeStrategyFromTrade(r,t),m(s=>s.map(a=>a.id===r?{...a,strategyIds:(a.strategyIds||[]).filter(o=>o!==t)}:a)),ee.success("标签已移除")}catch{ee.error("操作失败")}},ir=r=>{ue(r),ae.setFieldsValue({expectedTrend:r.expectedTrend,strategyIds:r.strategyIds||[],entryReason:r.entryReason||"",stopLossReason:r.stopLossReason||"",takeProfitReason:r.takeProfitReason||"",notes:r.notes||""}),H(!0)},lr=async()=>{try{const r=ae.getFieldsValue();await pe.updateTrade(C.id,r),ee.success("保存成功"),H(!1),qe()}catch{ee.error("保存失败")}},dr=()=>{const r=ae.getFieldsValue();if(!r.entryReason&&!r.stopLossReason&&!r.takeProfitReason&&!r.notes){ee.warning("请先填写复盘内容再保存为策略");return}Be.resetFields(),Be.setFieldsValue({category:"通用",color:"#eab308"}),at(!0)},cr=async()=>{var r,t;try{const s=await Be.validateFields(),a=ae.getFieldsValue(),o=[];a.entryReason&&o.push(`【入场】${a.entryReason}`),a.stopLossReason&&o.push(`【止损】${a.stopLossReason}`),a.takeProfitReason&&o.push(`【止盈】${a.takeProfitReason}`),a.notes&&o.push(`【备注】${a.notes}`);const l=typeof s.color=="string"?s.color:((t=(r=s.color)==null?void 0:r.toHexString)==null?void 0:t.call(r))||"#eab308",d=await pe.createStrategy({name:s.name,description:o.join(`
`),color:l,category:s.category}),h=a.strategyIds||[];h.includes(d.id)||ae.setFieldsValue({strategyIds:[...h,d.id]});const y=await pe.getAllStrategies();E(y),at(!1),ee.success("策略创建成功，已自动关联到当前交易")}catch(s){console.error("保存策略失败:",s),ee.error("保存策略失败")}},pr=async r=>{try{await pe.deleteTrade(r),ee.success("删除成功"),qe()}catch{ee.error("删除失败")}},We=(r,t,s,a)=>{var o;if(Ne({tradeId:r,field:t,trade:a}),G==="tick"){const l=(a==null?void 0:a[t])??((o=a==null?void 0:a.jigsawData)==null?void 0:o[t]);ge(l??null)}else ge(s)},Ge=N.useCallback(async(r,t,s)=>{try{let a;if(G==="tick")a=s!=null?Math.round(s):null;else{const o=_t(r.instrumentCode,u),l=Math.abs(r.openQuantity||1);a=s!=null&&o>0&&l>0?Math.round(s/o/l):null}await pe.updateTrade(r.id,{[t]:a}),m(o=>o.map(l=>l.id===r.id?{...l,[t]:a}:l)),Ne({tradeId:null,field:null,trade:null}),ge(null)}catch(a){ee.error("保存失败"),console.error(a)}},[G,u]);N.useEffect(()=>{const r=t=>{if(!J.tradeId||!J.trade)return;const s=Ee.current;s&&(s.contains(t.target)||s===t.target)||t.target.closest(".ant-input-number")||Ge(J.trade,J.field,he)};return document.addEventListener("mousedown",r),()=>document.removeEventListener("mousedown",r)},[J,he,Ge]);const yt=()=>{Ne({tradeId:null,field:null,trade:null}),ge(null)},xr=()=>{const r=g.map(a=>{var l,d,h;const o={品种:a.instrumentCode,时间:ce(a.openTime).format("YYYY-MM-DD HH:mm:ss"),方向:a.direction==="LONG"?"多":"空",数量:a.openQuantity,开仓价:a.openPrice,平仓价:a.closePrice,盈亏:a.pnl,手续费:Te(a,u),时段:a.marketSession,持仓时长:Xe(a.holdingSeconds),数据来源:a.source==="jigsaw"?"Jigsaw":"ATAS"};if(j){const y=a.mae??((l=a.jigsawData)==null?void 0:l.mae),b=a.mfe??((d=a.jigsawData)==null?void 0:d.mfe),w=a.fills??((h=a.jigsawData)==null?void 0:h.fills),z=y!==void 0?L(y,a.instrumentCode,a.openQuantity,u):null,A=b!==void 0?L(b,a.instrumentCode,a.openQuantity,u):null;o["MAE(ticks)"]=y??"",o["MAE(美元)"]=z?(-z).toFixed(2):"",o["MFE(ticks)"]=b??"",o["MFE(美元)"]=A?A.toFixed(2):"",o.成交次数=w??"";const O=Le(a.pnl,z),f=ze(A,a.pnl),k=Wt(z,A,a.pnl),B=Ze(z,a.pnl,a.holdingSeconds),W=Gt(w,a.openQuantity),je=Ue(a,z,A);o.风险回报比=O!==null?O.toFixed(2):"",o["利润捕获率(%)"]=f!==null?f.toFixed(1):"",o.风险占用比=k!==null?k.toFixed(2):"",o["回撤压力(1-5)"]=B!==null?B.toFixed(1):"",o.执行复杂度=W!==null?W.toFixed(1):"",o.自动诊断=je.map(we=>we.label).join(", ")}return o}),t=dt.json_to_sheet(r),s=dt.book_new();dt.book_append_sheet(s,t,"交易记录"),gr(s,`交易明细_${ce().format("MMDD_HHmm")}.xlsx`)},mr=()=>{T({instrument:"ALL",direction:"ALL",result:"ALL",session:"ALL",strategy:"ALL",dateRange:null,keyword:"",source:"ALL"})},Re=v.instrument!=="ALL"||v.direction!=="ALL"||v.result!=="ALL"||v.source!=="ALL"||v.rating!=="ALL"||v.dateRange!==null||v.keyword!=="",He=g.filter(r=>r.pnl>0),_e=g.filter(r=>r.pnl<0),ft=g.reduce((r,t)=>r+Te(t,u),0),it=g.reduce((r,t)=>r+(t.pnl||0),0),Ve=He.reduce((r,t)=>r+t.pnl,0),Je=Math.abs(_e.reduce((r,t)=>r+t.pnl,0)),q={total:g.length,pnl:it,netPnL:it-ft,totalFee:ft,grossProfit:Ve,grossLoss:Je,wins:He.length,losses:_e.length,avgWin:He.length>0?Ve/He.length:0,avgLoss:_e.length>0?Je/_e.length:0,profitFactor:Je>0&&Ve>0?Ve/Je:0,expectancy:g.length>0?it/g.length:0},U=j?(()=>{const r=g.filter(f=>{var k;return(f.mae??((k=f.jigsawData)==null?void 0:k.mae))!==void 0}),t=g.filter(f=>{var k;return(f.mfe??((k=f.jigsawData)==null?void 0:k.mfe))!==void 0}),s=r.reduce((f,k)=>{var W;const B=k.mae??((W=k.jigsawData)==null?void 0:W.mae)??0;return f+L(B,k.instrumentCode,k.openQuantity,u)},0),a=t.reduce((f,k)=>{var W;const B=k.mfe??((W=k.jigsawData)==null?void 0:W.mfe)??0;return f+L(B,k.instrumentCode,k.openQuantity,u)},0);let o=0,l=0,d=0,h=0,y=0,b=0,w={perfect:0,roller:0,earlyExit:0,badEntry:0,greed:0,badExit:0,goodStop:0};g.forEach(f=>{var Ae,Ie;const k=f.mae??((Ae=f.jigsawData)==null?void 0:Ae.mae),B=f.mfe??((Ie=f.jigsawData)==null?void 0:Ie.mfe),W=k!==void 0?L(k,f.instrumentCode,f.openQuantity,u):null,je=B!==void 0?L(B,f.instrumentCode,f.openQuantity,u):null,we=Le(f.pnl,W);we!==null&&(o+=we,l++);const Pe=ze(je,f.pnl);Pe!==null&&(d+=Pe,h++);const De=Ze(W,f.pnl,f.holdingSeconds);De!==null&&(y+=De,b++),Ue(f,W,je).forEach($e=>{w[$e.type]!==void 0&&w[$e.type]++})});let z=0;r.forEach(f=>{var W;const k=f.mae??((W=f.jigsawData)==null?void 0:W.mae)??0,B=L(k,f.instrumentCode,f.openQuantity,u)||0;B>z&&(z=B)});const A=g.filter(f=>f.pnl!==null&&f.pnl!==void 0&&f.pnl<0),O=A.length>0?Math.max(...A.map(f=>Math.abs(f.pnl||0))):0;return{avgMAE:r.length>0?s/r.length:0,avgMFE:t.length>0?a/t.length:0,maxMAE:z,maxLoss:O,totalFills:g.reduce((f,k)=>{var B;return f+(k.fills??((B=k.jigsawData)==null?void 0:B.fills)??0)},0),avgRMultiple:l>0?o/l:0,avgProfitCapture:h>0?d/h:0,avgStressScore:b>0?y/b:0,diagnosisCounts:w}})():null,ur=[{title:"时间",dataIndex:"openTime",key:"openTime",width:200,render:(r,t)=>{if(t.isMergedGroup&&t.mergeStats){const a=t.mergeStats;return e.jsxs("div",{style:{padding:"4px 0",cursor:"pointer",display:"flex",alignItems:"center",gap:"12px",position:"relative",marginLeft:"-12px",paddingLeft:"12px"},onClick:o=>{o.stopPropagation(),er(t)},children:[e.jsx("div",{style:{position:"absolute",left:0,top:"10%",bottom:"10%",width:"3px",background:"linear-gradient(to bottom, transparent, var(--color-brand), transparent)",opacity:.4,borderRadius:"0 4px 4px 0"}}),e.jsx("div",{style:{width:32,height:32,borderRadius:"8px",background:"var(--color-brand)10",display:"flex",alignItems:"center",justifyContent:"center",border:"1px solid var(--color-brand)20"},children:e.jsx(At,{style:{color:"var(--color-brand)",fontSize:16}})}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"2px"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[e.jsx("span",{style:{fontSize:"13px",fontWeight:600,color:"var(--text-primary)",fontFamily:"JetBrains Mono, monospace"},children:ce(a.firstOpenTime).format("MM-DD HH:mm")}),e.jsx("span",{style:{color:"var(--text-tertiary)",fontSize:"12px"},children:"→"}),e.jsx("span",{style:{fontSize:"13px",fontWeight:600,color:"var(--text-primary)",fontFamily:"JetBrains Mono, monospace"},children:ce(a.lastCloseTime).format("HH:mm")})]}),e.jsxs("div",{style:{fontSize:"11px",color:"var(--color-brand)",opacity:.8,fontWeight:500,display:"flex",alignItems:"center",gap:"6px"},children:[a.tradeCount," 笔合并交易记录",Ur(t.id)&&e.jsx(I,{title:"已完成复盘",children:e.jsx(Qt,{style:{color:"#52c41a",fontSize:12}})})]})]})]})}const s=ea(t);return e.jsxs("div",{style:{padding:"4px 0",display:"flex",alignItems:"center",gap:"8px"},children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-mono text-sm",style:{color:"var(--text-primary)"},children:ce(r).format("MM-DD HH:mm:ss")}),e.jsx("div",{className:"text-xs",style:{color:"var(--text-tertiary)"},children:ce(r).format("YYYY")})]}),s&&e.jsx(I,{title:"已完成复盘",children:e.jsx(Qt,{style:{color:"#52c41a",fontSize:12}})})]})},sorter:(r,t)=>new Date(r.openTime)-new Date(t.openTime)},{title:"品种",dataIndex:"instrumentCode",key:"instrumentCode",width:120,render:r=>e.jsx("span",{className:"font-mono font-semibold text-sm px-3 py-1.5 rounded",style:{background:"var(--bg-tertiary)",color:"var(--text-primary)"},children:r})},{title:"方向",dataIndex:"direction",key:"direction",width:60,render:r=>e.jsx("span",{className:"font-mono text-xs font-semibold",style:{color:"var(--text-secondary)"},children:r==="LONG"?"多":"空"})},{title:"数量",key:"quantity",width:90,align:"right",render:(r,t)=>t.isMergedGroup&&t.mergeStats?e.jsxs("div",{className:"text-right",children:[e.jsx("span",{className:"font-mono font-semibold text-base",style:{color:"var(--text-primary)"},children:t.mergeStats.totalQuantity}),e.jsxs("div",{className:"text-[10px]",style:{color:"var(--text-tertiary)"},children:["峰值 ",t.mergeStats.maxConcurrentQty]})]}):e.jsx("span",{className:"font-mono font-semibold text-base",style:{color:"var(--text-primary)"},children:Math.abs(t.openQuantity||0)})},{title:"价格",key:"prices",width:160,align:"right",render:(r,t)=>{var s,a,o,l;if(t.isMergedGroup&&t.mergeStats){const d=t.mergeStats;return e.jsxs("div",{className:"font-mono",style:{padding:"4px 0"},children:[e.jsx("div",{className:"text-sm",style:{color:"var(--text-primary)"},children:(s=d.weightedOpenPrice)==null?void 0:s.toFixed(2)}),e.jsxs("div",{className:"text-xs",style:{color:"var(--text-tertiary)"},children:["→ ",(a=d.weightedClosePrice)==null?void 0:a.toFixed(2)," ",e.jsx("span",{style:{color:"var(--color-brand)",fontSize:9},children:"加权"})]})]})}return e.jsxs("div",{className:"font-mono",style:{padding:"4px 0"},children:[e.jsx("div",{className:"text-sm",style:{color:"var(--text-primary)"},children:(o=t.openPrice)==null?void 0:o.toFixed(2)}),e.jsxs("div",{className:"text-xs",style:{color:"var(--text-tertiary)"},children:["→ ",(l=t.closePrice)==null?void 0:l.toFixed(2)]})]})}},{title:"盈亏",dataIndex:"pnl",key:"pnl",width:140,align:"right",sorter:(r,t)=>(r.pnl||0)-(t.pnl||0),render:(r,t)=>{var s,a;if(t.isMergedGroup&&t.mergeStats){const o=t.mergeStats;return e.jsxs("div",{children:[e.jsxs("div",{className:"font-mono font-bold text-base",style:{color:o.totalPnL>=0?"var(--color-profit)":"var(--color-loss)"},children:[o.totalPnL>=0?"+":"",(s=o.totalPnL)==null?void 0:s.toFixed(2)]}),e.jsxs("div",{className:"text-[10px]",style:{color:"var(--text-tertiary)"},children:["均 ",o.avgPnL>=0?"+":"",(a=o.avgPnL)==null?void 0:a.toFixed(0),"/笔"]})]})}return e.jsxs("div",{className:"font-mono font-bold text-base",style:{color:(r||0)>=0?"var(--color-profit)":"var(--color-loss)"},children:[(r||0)>=0?"+":"",(r||0).toFixed(2)]})}},{title:"手续费",key:"fee",width:80,align:"right",sorter:(r,t)=>Te(r,u)-Te(t,u),render:(r,t)=>{const s=Te(t,u);return e.jsx("div",{className:"font-mono text-xs",style:{color:"var(--text-tertiary)"},children:s>0?`$${s.toFixed(2)}`:"-"})}},{title:"费率",key:"feeRatio",width:60,align:"right",render:(r,t)=>{const s=Te(t,u),a=Math.abs(t.pnl||0);if(s<=0||a<=0)return e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"});const o=s/a*100,l=o>20;return e.jsxs("span",{className:"font-mono text-xs",style:{color:l?"var(--color-loss)":"var(--text-tertiary)"},children:[o.toFixed(0),"%"]})}},{title:e.jsx(I,{title:e.jsxs("span",{children:["时段根据开仓时间自动判断",e.jsx("br",{}),"如显示不正确，请在",e.jsx("b",{children:"设置"}),"中调整时区"]}),placement:"top",children:e.jsxs("span",{style:{cursor:"help",display:"inline-flex",alignItems:"center",gap:4},children:["时段",e.jsx(Ce,{style:{fontSize:10,opacity:.5}})]})}),dataIndex:"marketSession",key:"marketSession",width:100,render:r=>e.jsx("span",{className:"text-xs",style:{color:"var(--text-tertiary)"},children:r})},{title:"时长",dataIndex:"holdingSeconds",key:"duration",width:100,align:"right",render:(r,t)=>t.isMergedGroup&&t.mergeStats?e.jsx("span",{className:"font-mono text-sm",style:{color:"var(--text-secondary)"},children:Xe(t.mergeStats.totalDuration)}):e.jsx("span",{className:"font-mono text-sm",style:{color:"var(--text-secondary)"},children:Xe(r)})},...j?[{title:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:4},children:[e.jsx("span",{children:"最大浮亏"}),e.jsx(I,{title:`点击切换输入模式：${G==="tick"?"当前Tick模式":"当前美元模式"}`,children:e.jsx("span",{onClick:r=>{r.stopPropagation(),Oe(t=>t==="tick"?"usd":"tick")},style:{cursor:"pointer",fontSize:10,padding:"1px 4px",borderRadius:3,background:G==="tick"?"var(--color-brand-bg)":"var(--bg-tertiary)",color:G==="tick"?"var(--color-brand)":"var(--text-tertiary)",border:`1px solid ${G==="tick"?"var(--color-brand)":"var(--border-secondary)"}`,fontWeight:600},children:G==="tick"?"T":"$"})})]}),key:"mae",width:110,align:"right",render:(r,t)=>{var l;if(t.isMergedGroup)return null;const s=t.mae??((l=t.jigsawData)==null?void 0:l.mae),a=s!=null?L(s,t.instrumentCode,t.openQuantity,u):null;return J.tradeId===t.id&&J.field==="mae"?e.jsx("div",{ref:Ee,children:e.jsx(qt,{autoFocus:!0,size:"small",value:he,onChange:ge,onPressEnter:()=>Ge(t,"mae",he),onKeyDown:d=>d.key==="Escape"&&yt(),prefix:G==="tick"?"T":"$",min:0,precision:0,style:{width:80},className:"mae-mfe-input"})}):s!=null?e.jsx(I,{title:G==="tick"?`$${(a==null?void 0:a.toFixed(0))||0}`:`${s} ticks`,children:e.jsx("span",{className:"font-mono text-sm cursor-pointer hover:text-[var(--color-brand)] transition-colors px-2 py-1 rounded hover:bg-[var(--bg-tertiary)] inline-block min-w-[50px] text-right",style:{color:"var(--text-secondary)"},onClick:d=>{d.stopPropagation(),We(t.id,"mae",Math.round(a||0),t)},children:G==="tick"?`${s}T`:`$${(a==null?void 0:a.toFixed(0))||0}`})}):e.jsx("span",{className:"cursor-pointer transition-all inline-flex items-center gap-1 px-2 py-1 rounded hover:bg-[var(--bg-tertiary)]",style:{color:"var(--text-quaternary)"},onClick:d=>{d.stopPropagation(),We(t.id,"mae",null,t)},title:"点击录入最大浮亏",children:e.jsx("span",{style:{fontSize:10,padding:"1px 4px",background:"var(--bg-tertiary)",borderRadius:3,border:"1px dashed var(--border-secondary)",color:"var(--text-tertiary)"},children:"+添加"})})}}]:[],...j?[{title:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:4},children:[e.jsx("span",{children:"最大浮盈"}),e.jsx(I,{title:`点击切换输入模式：${G==="tick"?"当前Tick模式":"当前美元模式"}`,children:e.jsx("span",{onClick:r=>{r.stopPropagation(),Oe(t=>t==="tick"?"usd":"tick")},style:{cursor:"pointer",fontSize:10,padding:"1px 4px",borderRadius:3,background:G==="tick"?"var(--color-brand-bg)":"var(--bg-tertiary)",color:G==="tick"?"var(--color-brand)":"var(--text-tertiary)",border:`1px solid ${G==="tick"?"var(--color-brand)":"var(--border-secondary)"}`,fontWeight:600},children:G==="tick"?"T":"$"})})]}),key:"mfe",width:110,align:"right",render:(r,t)=>{var l;if(t.isMergedGroup)return null;const s=t.mfe??((l=t.jigsawData)==null?void 0:l.mfe),a=s!=null?L(s,t.instrumentCode,t.openQuantity,u):null;return J.tradeId===t.id&&J.field==="mfe"?e.jsx("div",{ref:Ee,children:e.jsx(qt,{autoFocus:!0,size:"small",value:he,onChange:ge,onPressEnter:()=>Ge(t,"mfe",he),onKeyDown:d=>d.key==="Escape"&&yt(),prefix:G==="tick"?"T":"$",min:0,precision:0,style:{width:80},className:"mae-mfe-input"})}):s!=null?e.jsx(I,{title:G==="tick"?`$${(a==null?void 0:a.toFixed(0))||0}`:`${s} ticks`,children:e.jsx("span",{className:"font-mono text-sm cursor-pointer hover:text-[var(--color-brand)] transition-colors px-2 py-1 rounded hover:bg-[var(--bg-tertiary)] inline-block min-w-[50px] text-right",style:{color:"var(--text-secondary)"},onClick:d=>{d.stopPropagation(),We(t.id,"mfe",Math.round(a||0),t)},children:G==="tick"?`${s}T`:`$${(a==null?void 0:a.toFixed(0))||0}`})}):e.jsx("span",{className:"cursor-pointer transition-all inline-flex items-center gap-1 px-2 py-1 rounded hover:bg-[var(--bg-tertiary)]",style:{color:"var(--text-quaternary)"},onClick:d=>{d.stopPropagation(),We(t.id,"mfe",null,t)},title:"点击录入最大浮盈",children:e.jsx("span",{style:{fontSize:10,padding:"1px 4px",background:"var(--bg-tertiary)",borderRadius:3,border:"1px dashed var(--border-secondary)",color:"var(--text-tertiary)"},children:"+添加"})})}}]:[],...j?[{title:"成交",key:"fills",width:60,align:"right",render:(r,t)=>{var a;const s=t.fills??((a=t.jigsawData)==null?void 0:a.fills);return s==null?e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"}):e.jsx("span",{className:"font-mono text-sm",style:{color:"var(--text-secondary)"},children:s})}}]:[],...j?[{title:"风险回报",key:"riskReward",width:80,align:"right",sorter:(r,t)=>{var d,h;const s=L(r.mae??((d=r.jigsawData)==null?void 0:d.mae),r.instrumentCode,r.openQuantity,u),a=L(t.mae??((h=t.jigsawData)==null?void 0:h.mae),t.instrumentCode,t.openQuantity,u),o=Le(r.pnl,s)||0,l=Le(t.pnl,a)||0;return o-l},render:(r,t)=>{var d;if(t.isMergedGroup)return null;const s=t.mae??((d=t.jigsawData)==null?void 0:d.mae);if(s==null)return e.jsx(I,{title:"录入 MAE 后自动计算",children:e.jsx("span",{style:{fontSize:9,color:"var(--text-quaternary)",fontStyle:"italic"},children:"需MAE"})});const a=L(s,t.instrumentCode,t.openQuantity,u),o=Le(t.pnl,a);if(o===null)return e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"});const l=o>=1;return e.jsxs("span",{className:"font-mono text-sm font-semibold",style:{color:l?"var(--color-profit)":"var(--text-secondary)"},children:[o.toFixed(1),"R"]})}}]:[],...j?[{title:"捕获率",key:"profitCapture",width:80,align:"right",sorter:(r,t)=>{var d,h;const s=L(r.mfe??((d=r.jigsawData)==null?void 0:d.mfe),r.instrumentCode,r.openQuantity,u),a=L(t.mfe??((h=t.jigsawData)==null?void 0:h.mfe),t.instrumentCode,t.openQuantity,u),o=ze(s,r.pnl)||0,l=ze(a,t.pnl)||0;return o-l},render:(r,t)=>{var h;if(t.isMergedGroup)return null;const s=t.mfe??((h=t.jigsawData)==null?void 0:h.mfe);if(s==null)return e.jsx(I,{title:"录入 MFE 后自动计算",children:e.jsx("span",{style:{fontSize:9,color:"var(--text-quaternary)",fontStyle:"italic"},children:"需MFE"})});const a=L(s,t.instrumentCode,t.openQuantity,u),o=ze(a,t.pnl);if(o===null)return e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"});const l=o>=80,d=o>100;return e.jsx(I,{title:d?"⚠️ 超过100%可能因分批建仓导致统计不准确":`利润捕获率: ${o.toFixed(1)}%`,children:e.jsxs("span",{className:"font-mono text-sm font-semibold",style:{color:d?"#f59e0b":l?"var(--color-profit)":"var(--text-secondary)",cursor:d?"help":"default"},children:[o.toFixed(0),"%",d&&e.jsx("span",{style:{marginLeft:2,fontSize:10},children:"⚠"})]})})}}]:[],...j?[{title:"压力",key:"stressScore",width:60,align:"right",render:(r,t)=>{var l;if(t.isMergedGroup)return null;const s=t.mae??((l=t.jigsawData)==null?void 0:l.mae);if(s==null)return e.jsx(I,{title:"录入 MAE 后自动计算",children:e.jsx("span",{style:{fontSize:9,color:"var(--text-quaternary)",fontStyle:"italic"},children:"需MAE"})});const a=L(s,t.instrumentCode,t.openQuantity,u),o=Ze(a,t.pnl,t.holdingSeconds);return o==null?e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"}):e.jsx("span",{className:"font-mono text-sm",style:{color:"var(--text-secondary)"},children:o.toFixed(1)})}}]:[],...j?[{title:"诊断",key:"diagnosis",width:100,render:(r,t)=>{var h,y;if(t.isMergedGroup)return null;const s=t.mae??((h=t.jigsawData)==null?void 0:h.mae),a=t.mfe??((y=t.jigsawData)==null?void 0:y.mfe);if(s==null&&a==null)return e.jsx(I,{title:"录入 MAE/MFE 后自动诊断",children:e.jsx("span",{style:{fontSize:9,color:"var(--text-quaternary)",fontStyle:"italic"},children:"需数据"})});const o=s!==void 0?L(s,t.instrumentCode,t.openQuantity,u):null,l=a!==void 0?L(a,t.instrumentCode,t.openQuantity,u):null,d=Ue(t,o,l);return d.length===0?e.jsx("span",{style:{color:"var(--text-tertiary)"},children:"-"}):e.jsx("span",{className:"text-xs",style:{color:"var(--text-tertiary)"},children:d.slice(0,2).map(b=>b.label).join(", ")})}}]:[],...j?[{title:"波动区间",key:"tradeRange",width:120,render:(r,t)=>{var d,h;if(t.isMergedGroup)return null;const s=t.mae??((d=t.jigsawData)==null?void 0:d.mae),a=t.mfe??((h=t.jigsawData)==null?void 0:h.mfe);if(s==null&&a==null)return e.jsx(I,{title:"录入 MAE/MFE 后显示波动区间",children:e.jsx("div",{style:{height:16,background:"var(--bg-tertiary)",borderRadius:2,display:"flex",alignItems:"center",justifyContent:"center"},children:e.jsx("span",{style:{fontSize:9,color:"var(--text-quaternary)",fontStyle:"italic"},children:"需数据"})})});const o=s!==void 0?L(s,t.instrumentCode,t.openQuantity,u):null,l=a!==void 0?L(a,t.instrumentCode,t.openQuantity,u):null;return e.jsx(Ht,{mae:s,mfe:a,pnl:t.pnl,maeUSD:o,mfeUSD:l})}}]:[],...j?[{title:"评级",key:"rating",width:60,align:"center",sorter:(r,t)=>{var d,h,y,b;const s=L(r.mae??((d=r.jigsawData)==null?void 0:d.mae),r.instrumentCode,r.openQuantity,u),a=L(r.mfe??((h=r.jigsawData)==null?void 0:h.mfe),r.instrumentCode,r.openQuantity,u),o=L(t.mae??((y=t.jigsawData)==null?void 0:y.mae),t.instrumentCode,t.openQuantity,u),l=L(t.mfe??((b=t.jigsawData)==null?void 0:b.mfe),t.instrumentCode,t.openQuantity,u);return et(r,s,a).score-et(t,o,l).score},render:(r,t)=>{var h,y;if(t.isMergedGroup)return null;const s=t.mae??((h=t.jigsawData)==null?void 0:h.mae),a=t.mfe??((y=t.jigsawData)==null?void 0:y.mfe);if(s==null&&a==null)return e.jsx(I,{title:"录入 MAE/MFE 后自动评级",children:e.jsx("span",{style:{fontSize:9,color:"var(--text-quaternary)",fontStyle:"italic"},children:"—"})});const o=s!==void 0?L(s,t.instrumentCode,t.openQuantity,u):null,l=a!==void 0?L(a,t.instrumentCode,t.openQuantity,u):null,d=et(t,o,l);return e.jsx("span",{className:"font-mono text-sm font-bold",style:{color:d.color},title:`${d.label} (${d.score}分)`,children:d.grade})}}]:[],{title:"策略",key:"strategyTags",width:140,render:(r,t)=>{const s=(t.strategyIds||[]).map(o=>sr(o)).filter(Boolean),a=D.filter(o=>{var l;return!((l=t.strategyIds)!=null&&l.includes(o.id))});return e.jsxs("div",{className:"flex flex-wrap items-center gap-1",children:[s.map(o=>e.jsx("span",{className:"text-xs px-2 py-0.5 rounded cursor-pointer",style:{background:"var(--bg-tertiary)",color:"var(--text-secondary)"},onClick:()=>nr(t.id,o.id),children:o.name},o.id)),a.length>0&&e.jsx(Ar,{menu:{items:a.map(o=>({key:o.id,label:o.name,onClick:()=>or(t.id,o.id)}))},trigger:["click"],children:e.jsx("span",{className:"text-xs cursor-pointer",style:{color:"var(--text-tertiary)"},children:"+"})})]})}},{title:"",key:"action",width:R?60:80,fixed:R?!1:"right",render:(r,t)=>e.jsxs(Ir,{size:2,children:[e.jsx(te,{type:"text",size:"small",icon:e.jsx(rt,{}),onClick:()=>ir(t),style:{color:"var(--text-tertiary)",padding:R?"2px 4px":"4px 8px"},className:"hover:!text-[var(--color-brand)]"}),e.jsx($r,{title:e.jsx("span",{style:{color:"var(--text-primary)"},children:"确认删除此交易记录？"}),onConfirm:()=>pr(t.id),okText:"删除",cancelText:"取消",okButtonProps:{danger:!0,size:"small"},cancelButtonProps:{size:"small"},children:e.jsx(te,{type:"text",size:"small",icon:e.jsx(Or,{}),style:{color:"var(--text-tertiary)",padding:R?"2px 4px":"4px 8px"},className:"hover:!text-[var(--color-loss)]"})})]})}],ht=e.jsx("div",{className:oe?"":"max-w-[1600px] mx-auto",style:oe?{position:"fixed",top:0,left:0,width:"100vw",height:"100vh",zIndex:99999,backgroundColor:"#0f0f10",padding:24,overflow:"auto",boxSizing:"border-box"}:{},children:e.jsxs("div",{className:"space-y-4 md:space-y-6",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-3",children:[e.jsxs("div",{children:[e.jsxs("h1",{className:"text-xl md:text-2xl font-medium tracking-tight",style:{color:"var(--text-primary)"},children:["交易明细",oe&&e.jsx("span",{style:{fontSize:12,marginLeft:8,color:"var(--text-tertiary)",fontWeight:400},children:"全屏模式 · ESC 退出"})]}),e.jsx("p",{className:"text-xs md:text-sm mt-1",style:{color:"var(--text-tertiary)"},children:"查看和管理所有交易记录"})]}),e.jsxs("div",{className:"flex items-center gap-1.5 md:gap-2 flex-wrap",children:[e.jsx(I,{title:V?"点击关闭合并显示":"点击开启自动合并加减仓交易",children:e.jsx(te,{size:"small",className:"md:size-default",icon:V?e.jsx(At,{}):e.jsx(fr,{}),onClick:()=>ye(!V),style:{background:V?"var(--color-brand-bg)":"var(--bg-tertiary)",borderColor:V?"var(--color-brand)":"var(--border-primary)",color:V?"var(--color-brand)":"var(--text-secondary)"},children:e.jsx("span",{className:"hidden sm:inline",children:V?"合并中":"未合并"})})}),e.jsxs(te,{size:"small",className:"md:size-default",icon:e.jsx(hr,{}),onClick:()=>me(!Se),style:{background:Re?"var(--color-brand-bg)":"var(--bg-tertiary)",borderColor:Re?"var(--color-brand)":"var(--border-primary)",color:Re?"var(--color-brand)":"var(--text-secondary)"},children:[e.jsx("span",{className:"hidden sm:inline",children:"筛选"})," ",Re&&`(${g.length})`]}),e.jsx(te,{size:"small",className:"md:size-default",icon:e.jsx(br,{}),onClick:qe,style:{background:"var(--bg-tertiary)",borderColor:"var(--border-primary)",color:"var(--text-secondary)"}}),e.jsx(te,{size:"small",className:"md:size-default",type:"primary",icon:e.jsx(vr,{}),onClick:xr,children:e.jsx("span",{className:"hidden sm:inline",children:"导出"})}),e.jsx(I,{title:oe?"退出全屏":"全屏显示",children:e.jsx(te,{size:"small",className:"hidden md:inline-flex",icon:oe?e.jsx(jr,{}):e.jsx(wr,{}),onClick:()=>ut(!oe),style:{background:oe?"var(--color-brand-bg)":"var(--bg-tertiary)",borderColor:oe?"var(--color-brand)":"var(--border-primary)",color:oe?"var(--color-brand)":"var(--text-secondary)"}})}),e.jsx(te,{size:"small",className:"md:size-default",icon:e.jsx(It,{}),onClick:()=>mt(!0),style:{background:"var(--bg-tertiary)",borderColor:"var(--border-primary)",color:"var(--text-secondary)"},children:e.jsx("span",{className:"hidden sm:inline",children:"设置"})})]})]}),Se&&e.jsx("div",{className:"p-3 md:p-4 rounded-lg",style:{background:"var(--bg-secondary)",border:"1px solid var(--border-primary)"},children:e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-3 md:flex md:flex-wrap gap-2 md:gap-3 items-center",children:[e.jsx(ve,{value:v.instrument,onChange:r=>T({...v,instrument:r}),className:"w-full md:w-[120px]",placeholder:"品种",options:[{value:"ALL",label:"全部品种"},...u.map(r=>({value:r.code,label:r.code}))]}),e.jsx(ve,{value:v.direction,onChange:r=>T({...v,direction:r}),className:"w-full md:w-[100px]",options:[{value:"ALL",label:"全部方向"},{value:"LONG",label:"多头"},{value:"SHORT",label:"空头"}]}),e.jsx(ve,{value:v.result,onChange:r=>T({...v,result:r}),className:"w-full md:w-[100px]",options:[{value:"ALL",label:"全部结果"},{value:"WIN",label:"盈利"},{value:"LOSS",label:"亏损"}]}),j&&e.jsx(ve,{value:v.source,onChange:r=>T({...v,source:r}),className:"w-full md:w-[110px]",options:[{value:"ALL",label:"全部来源"},{value:"atas",label:"ATAS"},{value:"jigsaw",label:"Jigsaw"}]}),j&&e.jsx(ve,{value:v.rating,onChange:r=>T({...v,rating:r}),className:"w-full md:w-[100px]",options:[{value:"ALL",label:"全部评级"},{value:"A",label:"A 优秀"},{value:"B",label:"B 良好"},{value:"C",label:"C 一般"},{value:"D",label:"D 较差"},{value:"F",label:"F 很差"}]}),e.jsx(_r,{value:v.dateRange,onChange:r=>T({...v,dateRange:r}),placeholder:["开始","结束"],className:"col-span-2 md:col-span-1 w-full md:w-[240px]"}),e.jsx(tt,{placeholder:"搜索...",value:v.keyword,onChange:r=>T({...v,keyword:r.target.value}),prefix:e.jsx(kr,{style:{color:"var(--text-tertiary)"}}),className:"col-span-2 md:col-span-1 w-full md:w-[180px]",allowClear:!0}),Re&&e.jsx(te,{type:"text",onClick:mr,style:{color:"var(--text-secondary)"},children:"重置"})]})}),e.jsx("div",{className:"p-3 md:p-5 rounded-lg",style:{background:"var(--bg-secondary)",border:"1px solid var(--border-primary)"},children:e.jsxs("div",{className:"flex flex-col md:flex-row md:items-baseline md:justify-between gap-4 md:gap-8",children:[e.jsxs("div",{className:"flex-shrink-0",children:[e.jsx("div",{className:"text-[10px] tracking-wider mb-1",style:{color:"var(--text-tertiary)"},children:"净盈亏"}),e.jsxs("div",{className:"text-2xl md:text-3xl font-mono font-bold",style:{color:q.netPnL>=0?"var(--color-profit)":"var(--color-loss)"},children:[q.netPnL>=0?"+":"",(q.netPnL??0).toFixed(2)]})]}),e.jsxs("div",{className:"grid grid-cols-4 sm:grid-cols-5 md:flex md:items-baseline gap-3 md:gap-6 lg:gap-8 overflow-x-auto",children:[e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"交易数"}),e.jsx("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:q.total})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"胜率"}),e.jsxs("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:[q.total>0?(q.wins/q.total*100).toFixed(0):0,"%"]})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"胜/负"}),e.jsxs("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:[q.wins,"/",q.losses]})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"盈亏比"}),e.jsx("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:(q.profitFactor??0).toFixed(2)})]}),e.jsxs("div",{className:"min-w-0 hidden sm:block",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"均盈"}),e.jsxs("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:["$",(q.avgWin??0).toFixed(0)]})]}),e.jsxs("div",{className:"min-w-0 hidden sm:block",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"均亏"}),e.jsxs("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:["$",(q.avgLoss??0).toFixed(0)]})]}),e.jsxs("div",{className:"min-w-0 hidden md:block",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"手续费"}),e.jsxs("div",{className:"text-base md:text-xl font-mono font-semibold",style:{color:"var(--text-tertiary)"},children:["$",(q.totalFee??0).toFixed(0)]})]}),j&&U&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"min-w-0 hidden lg:block",children:[e.jsx(I,{title:"单笔最大实际亏损（平仓后的亏损金额）",children:e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--color-loss)"},children:"最大亏损"})}),e.jsxs("div",{className:"text-xl font-mono font-semibold",style:{color:"var(--color-loss)"},children:["$",(U.maxLoss??0).toFixed(0)]})]}),e.jsxs("div",{className:"min-w-0 hidden lg:block",children:[e.jsx(I,{title:"单笔最大浮亏（持仓期间承受的最大不利偏移）",children:e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"最大浮亏"})}),e.jsxs("div",{className:"text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:["$",(U.maxMAE??0).toFixed(0)]})]}),e.jsxs("div",{className:"min-w-0 hidden xl:block",children:[e.jsx(I,{title:"平均每笔交易承受的最大浮亏",children:e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"均浮亏"})}),e.jsxs("div",{className:"text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:["$",(U.avgMAE??0).toFixed(0)]})]}),e.jsxs("div",{className:"min-w-0 hidden xl:block",children:[e.jsx(I,{title:"平均每笔交易达到的最大浮盈",children:e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"均浮盈"})}),e.jsxs("div",{className:"text-xl font-mono font-semibold",style:{color:"var(--text-secondary)"},children:["$",(U.avgMFE??0).toFixed(0)]})]})]})]})]})}),j&&U&&e.jsxs("div",{className:"mt-3 p-3 md:p-4 rounded-lg",style:{background:"var(--bg-secondary)",border:"1px solid var(--border-primary)"},children:[e.jsx("div",{className:"flex items-center gap-2 mb-3",children:e.jsx("span",{className:"text-[10px] font-semibold tracking-wider",style:{color:"var(--text-tertiary)"},children:"高级分析"})}),e.jsxs("div",{className:"grid grid-cols-3 sm:grid-cols-4 md:flex md:items-baseline gap-3 md:gap-6 lg:gap-8 overflow-x-auto",children:[e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"风险回报"}),e.jsxs("div",{className:"text-sm md:text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:[(U.avgRMultiple??0).toFixed(2),"R"]})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"捕获率"}),e.jsxs("div",{className:"text-sm md:text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:[(U.avgProfitCapture??0).toFixed(0),"%"]})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"压力指数"}),e.jsxs("div",{className:"text-sm md:text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:[(U.avgStressScore??0).toFixed(1),"/5"]})]}),e.jsxs("div",{className:"min-w-0 hidden sm:block",children:[e.jsx("div",{className:"text-[9px] md:text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--color-profit)"},children:"完美"}),e.jsx("div",{className:"text-sm md:text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:U.diagnosisCounts.perfect})]}),e.jsxs("div",{className:"min-w-0 hidden md:block",children:[e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--text-tertiary)"},children:"扛赢"}),e.jsx("div",{className:"text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:U.diagnosisCounts.roller})]}),e.jsxs("div",{className:"min-w-0 hidden md:block",children:[e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--color-loss)"},children:"方向错"}),e.jsx("div",{className:"text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:U.diagnosisCounts.badEntry})]}),e.jsxs("div",{className:"min-w-0 hidden lg:block",children:[e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--color-loss)"},children:"浮盈亏"}),e.jsx("div",{className:"text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:U.diagnosisCounts.greed})]}),e.jsxs("div",{className:"min-w-0 hidden lg:block",children:[e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:"var(--color-loss)"},children:"扛亏"}),e.jsx("div",{className:"text-lg font-mono font-semibold",style:{color:"var(--text-secondary)"},children:U.diagnosisCounts.badExit})]}),e.jsxs("div",{className:"min-w-0 hidden xl:block md:ml-auto md:pl-6 md:border-l md:border-[var(--border-primary)]",children:[e.jsx("div",{className:"text-[10px] tracking-wider mb-1 truncate",style:{color:q.grossProfit>0&&q.totalFee/q.grossProfit*100>15?"var(--color-loss)":"var(--text-tertiary)"},children:"手续费占比"}),e.jsxs("div",{className:"text-lg font-mono font-semibold",style:{color:q.grossProfit>0&&q.totalFee/q.grossProfit*100>15?"var(--color-loss)":"var(--text-secondary)"},children:[q.grossProfit>0?(q.totalFee/q.grossProfit*100).toFixed(1):0,"%"]})]})]})]}),(()=>{const t=g.filter(w=>!w.isMergedGroup&&(w.mae===null||w.mae===void 0||w.mae===0)&&(w.mfe===null||w.mfe===void 0||w.mfe===0)).length,s=g.filter(w=>!w.isMergedGroup).length,o=100-(s>0?Math.round(t/s*100):0);if(t===0||!j)return null;const l={beginner:["逐笔复盘 MAE/MFE，是从散户蜕变为职业交易员的必经之路","了解每笔交易的最大波动，是建立交易纪律的第一步","专业交易员不只看结果，更关注过程中的风险暴露"],intermediate:["记录 MAE 帮你认识真实风险，记录 MFE 帮你优化止盈","数据不会骗人，复盘让你看见自己的交易盲区","每一个数字背后，都是一次成长的机会"],advanced:["坚持到这里，你已经超越了 90% 的交易者","最好的交易日记，是用数据写成的","再坚持一下，完整的数据会给你惊喜"]};let d;o<30?d=l.beginner:o<70?d=l.intermediate:d=l.advanced;const y=new Date().toDateString().split("").reduce((w,z)=>w+z.charCodeAt(0),0)%d.length,b=d[y];return e.jsxs("div",{style:{marginTop:12,background:"var(--bg-secondary)",border:"1px solid var(--border-primary)",borderRadius:"8px",overflow:"hidden"},children:[e.jsxs("div",{style:{padding:"16px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:20},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:14},children:[e.jsx("div",{style:{width:42,height:42,borderRadius:"50%",background:`conic-gradient(var(--color-brand) ${o}%, var(--bg-tertiary) 0%)`,display:"flex",alignItems:"center",justifyContent:"center",position:"relative",flexShrink:0},children:e.jsxs("div",{style:{width:34,height:34,borderRadius:"50%",background:"var(--bg-secondary)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,color:"var(--text-primary)"},children:[o,"%"]})}),e.jsx("div",{children:(()=>{const w=[{min:0,max:30,name:"交易新手",next:"数据记录者",icon:"🌱",color:"#94a3b8"},{min:30,max:50,name:"数据记录者",next:"复盘学徒",icon:"📊",color:"#60a5fa"},{min:50,max:70,name:"复盘学徒",next:"交易分析师",icon:"📈",color:"#818cf8"},{min:70,max:90,name:"交易分析师",next:"数据大师",icon:"🎯",color:"#a855f7"},{min:90,max:100,name:"数据大师",next:null,icon:"👑",color:"#f59e0b"}],z=w.find(A=>o>=A.min&&(A.next===null||o<A.max))||w[0];return e.jsxs(e.Fragment,{children:[e.jsxs("div",{style:{fontSize:13,fontWeight:600,color:z.color,marginBottom:4,display:"flex",alignItems:"center",gap:6},children:[e.jsx("span",{children:z.icon}),e.jsx("span",{children:z.name})]}),e.jsx("div",{style:{fontSize:11,color:"var(--text-secondary)",lineHeight:1.5},children:z.next?e.jsxs(e.Fragment,{children:["职业交易员 ",e.jsx("span",{style:{color:"var(--text-primary)",fontWeight:700},children:re||"访客"}),"，你还需补全 ",e.jsx("span",{style:{fontWeight:700,color:"var(--color-brand)"},children:t})," 笔 MAE/MFE 数据， 即可晋升为「",e.jsx("span",{style:{fontWeight:600,color:z.color},children:z.next}),"」"]}):e.jsxs("span",{style:{color:"var(--color-profit)",fontWeight:600},children:["🎉 卓越！交易员 ",re,"，你已补全所有数据，正以「",z.name,"」的姿态俯瞰市场"]})})]})})()})]}),e.jsx("div",{style:{display:"flex",alignItems:"center",gap:8},children:e.jsx(I,{title:"在表格的 MAE/MFE 列中，直接点击空白单元格即可录入数据",children:e.jsx(te,{type:"text",size:"small",style:{fontSize:11,color:"var(--text-tertiary)",padding:"2px 8px",height:"auto"},children:"如何录入？"})})})]}),e.jsxs("div",{style:{padding:"10px 20px",background:"var(--bg-tertiary)",borderTop:"1px solid var(--border-primary)",display:"flex",alignItems:"center",gap:10},children:[e.jsx("span",{style:{fontSize:12,opacity:.5},children:"💡"}),e.jsxs("span",{style:{fontSize:11,color:"var(--text-secondary)",fontStyle:"italic",letterSpacing:"0.2px"},children:['"',b,'"']})]})]})})(),e.jsx("div",{ref:gt,className:"rounded-lg overflow-hidden table-drag-scroll",style:{background:"var(--bg-secondary)",border:"1px solid var(--border-primary)",cursor:"grab",marginTop:12},children:e.jsx(Sr,{columns:ur.filter(r=>!xe.hiddenColumns.includes(r.key)),dataSource:g,rowKey:"id",loading:p,pagination:{showSizeChanger:!0,showQuickJumper:!0,defaultPageSize:20,pageSizeOptions:["10","20","50","100"],showTotal:(r,t)=>e.jsxs("span",{style:{color:"var(--text-secondary)"},children:["显示 ",t[0],"-",t[1]," 条，共 ",r," 条"]})},scroll:{x:j?2e3:1100},size:((bt=Zt[xe.rowHeight])==null?void 0:bt.size)||"middle",className:`binance-table row-height-${xe.rowHeight}`,rowClassName:r=>r.isMergedGroup?"merged-group-row":""})}),e.jsx(ct,{title:Z&&e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12},children:[e.jsx("div",{className:"hidden sm:flex",style:{width:40,height:40,background:"var(--bg-tertiary)",borderRadius:"50%",alignItems:"center",justifyContent:"center",border:"1px solid var(--border-primary)"},children:e.jsx($t,{style:{fontSize:18,color:"var(--text-secondary)"}})}),e.jsxs("div",{children:[e.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--text-primary)",letterSpacing:"-0.3px"},children:"持仓分析"}),e.jsxs("div",{style:{fontSize:10,color:"var(--text-tertiary)",textTransform:"uppercase",letterSpacing:"0.5px",marginTop:2},children:[((vt=Z.mergeStats)==null?void 0:vt.tradeCount)||0," TRADES"]})]})]}),placement:"right",width:R?"100vw":"calc(100vw - 240px)",open:c,onClose:tr,styles:{header:{background:"var(--bg-primary)",borderBottom:"1px solid var(--border-primary)",padding:R?"16px":"20px 32px"},body:{background:"var(--bg-primary)",padding:0,overflow:"auto"}},destroyOnClose:!0,children:Z&&Z.mergeStats&&(()=>{const r=Z.mergeStats,t=r.trades||[],s=t[0],a=(s==null?void 0:s.direction)==="LONG"?1:-1,o=R;return e.jsxs("div",{style:{padding:0},children:[e.jsx("div",{style:{padding:o?"16px":"32px"},children:e.jsx(ta,{trades:t,overallDirection:a,dayjs:ce,tradeGroupId:(Z==null?void 0:Z.id)||"default",onStartReview:nt,reviewNotes:X})}),e.jsxs("div",{style:{padding:o?"0 16px 32px":"0 32px 48px"},children:[e.jsxs("div",{style:{fontSize:o?11:12,fontWeight:700,color:"var(--text-tertiary)",textTransform:"uppercase",letterSpacing:"1px",marginBottom:o?12:20,display:"flex",alignItems:"center",gap:8},children:[e.jsx("div",{style:{width:12,height:1,background:"var(--border-primary)"}}),"交易明细"]}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:o?"80px 100px 60px 80px 100px":"100px 120px 80px 100px 120px 100px 1fr",gap:o?8:12,padding:o?"0 12px 10px":"0 16px 12px",borderBottom:"1px solid var(--border-primary)",fontSize:o?9:10,fontWeight:600,color:"var(--text-tertiary)",textTransform:"uppercase",letterSpacing:"0.5px",overflowX:o?"auto":"visible",minWidth:o?"max-content":"auto"},children:[e.jsx("div",{children:"操作"}),e.jsx("div",{children:"执行时间"}),e.jsx("div",{children:"方向"}),e.jsx("div",{style:{textAlign:"right"},children:"数量"}),e.jsx("div",{style:{textAlign:"right"},children:"成交价格"}),e.jsx("div",{style:{textAlign:"right"},children:"当前持仓"}),e.jsx("div",{style:{textAlign:"right"},children:"盈亏"})]}),e.jsx("div",{style:{display:"flex",flexDirection:"column"},children:(()=>{const l=[];t.forEach((y,b)=>{const w=Math.abs(y.openQuantity||1);l.push({time:new Date(y.openTime).getTime(),type:"open",price:y.openPrice,qty:w,trade:y,tradeIdx:b}),l.push({time:new Date(y.closeTime).getTime(),type:"close",price:y.closePrice,qty:w,trade:y,tradeIdx:b})}),l.sort((y,b)=>y.time-b.time);let d=0,h=0;return l.map((y,b)=>{const w=d,z=h;let A,O;const f=y.trade,k=f.pnl||0,B=k>=0;if(y.type==="open"){w===0?h=y.price:h=(w*h+y.qty*y.price)/(w+y.qty),d+=y.qty,A=w===0?"首仓":"加仓";const W=(y.price-z)*a;O=w===0?"var(--text-primary)":W>0?"#22c55e":"#ef4444"}else d-=y.qty,A=d===0?"平仓":"减仓",O=(y.price-z)*a>0?"#22c55e":"#ef4444";return e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"100px 120px 80px 100px 120px 100px 1fr",gap:12,padding:"16px",borderBottom:"1px solid var(--border-primary)",alignItems:"center",fontSize:12,transition:"background 0.2s"},className:"minimal-row",children:[e.jsx("div",{children:e.jsx("span",{onClick:()=>nt(b,{label:A,color:O,time:y.time,price:y.price,qty:y.qty,type:y.type}),style:{padding:"2px 0",color:O,fontWeight:700,fontSize:11,cursor:"pointer",borderBottom:X[b]?`2px solid ${O}`:"none",display:"inline-flex",alignItems:"center",gap:4},children:A})}),e.jsx("div",{style:{fontFamily:"JetBrains Mono, monospace",color:"var(--text-secondary)",fontSize:11},children:ce(y.time).format("HH:mm:ss")}),e.jsx("div",{children:e.jsx("span",{style:{fontSize:10,fontWeight:700,color:f.direction==="LONG"?"#22c55e":"#ef4444",opacity:.8},children:f.direction==="LONG"?"BUY":"SELL"})}),e.jsxs("div",{style:{textAlign:"right",fontFamily:"JetBrains Mono, monospace",fontWeight:600,color:"var(--text-primary)"},children:[y.type==="open"?"+":"-",y.qty]}),e.jsx("div",{style:{textAlign:"right",fontFamily:"JetBrains Mono, monospace",color:"var(--text-secondary)"},children:y.price.toFixed(2)}),e.jsx("div",{style:{textAlign:"right",fontFamily:"JetBrains Mono, monospace",color:"var(--text-tertiary)",fontSize:11},children:d.toFixed(1)}),e.jsx("div",{style:{textAlign:"right",fontFamily:"JetBrains Mono, monospace",fontWeight:700,color:y.type==="close"?B?"#22c55e":"#ef4444":"transparent"},children:y.type==="close"?`${B?"+":""}${k.toFixed(2)}`:""})]},b)})})()}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"100px 120px 80px 100px 120px 100px 1fr",gap:12,padding:"20px 16px",fontSize:12,fontWeight:700,color:"var(--text-primary)"},children:[e.jsx("div",{style:{color:"var(--text-tertiary)",fontSize:10,textTransform:"uppercase"},children:"Summary"}),e.jsx("div",{}),e.jsx("div",{}),e.jsx("div",{style:{textAlign:"right",fontFamily:"JetBrains Mono, monospace"},children:t.reduce((l,d)=>l+Math.abs(d.openQuantity||1),0)}),e.jsx("div",{}),e.jsx("div",{}),e.jsxs("div",{style:{textAlign:"right",fontFamily:"JetBrains Mono, monospace",fontSize:14,color:r.totalPnl>=0?"#22c55e":"#ef4444"},children:[r.totalPnl>=0?"+":"",(r.totalPnl||0).toFixed(2)]})]})]}),Object.keys(X).length>0&&(()=>{const l=[];t.forEach((b,w)=>{const z=Math.abs(b.openQuantity||1);l.push({time:new Date(b.openTime).getTime(),type:"open",price:b.openPrice,qty:z,trade:b,tradeIdx:w}),l.push({time:new Date(b.closeTime).getTime(),type:"close",price:b.closePrice,qty:z,trade:b,tradeIdx:w})}),l.sort((b,w)=>b.time-w.time);let d=0,h=0;const y=l.map(b=>{const w=d,z=h;let A,O;if(b.type==="open"){w===0?h=b.price:h=(w*h+b.qty*b.price)/(w+b.qty),d+=b.qty,A=w===0?"首仓":"加仓";const f=(b.price-z)*a;O=w===0?"var(--text-primary)":f>0?"#22c55e":"#ef4444"}else d-=b.qty,A=d===0?"平仓":"减仓",O=(b.price-z)*a>0?"#22c55e":"#ef4444";return{label:A,color:O,time:b.time,price:b.price,qty:b.qty,type:b.type}});return e.jsx("div",{style:{padding:"0 32px 64px"},children:e.jsxs("div",{style:{borderTop:"1px solid var(--border-primary)",paddingTop:32},children:[e.jsxs("div",{style:{fontSize:12,fontWeight:700,color:"var(--text-tertiary)",textTransform:"uppercase",letterSpacing:"1px",marginBottom:24,display:"flex",alignItems:"center",gap:8},children:[e.jsx("div",{style:{width:12,height:1,background:"var(--border-primary)"}}),"复盘笔记"]}),e.jsx("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(300px, 1fr))",gap:16},children:Object.entries(X).map(([b,w])=>{if(!Object.values(w).some(f=>f&&f.trim()))return null;const A=parseInt(b),O=y[A]||{label:"复盘",color:"var(--text-primary)"};return e.jsxs("div",{onClick:()=>nt(A,O),style:{padding:"20px",background:"var(--bg-secondary)",borderRadius:"8px",cursor:"pointer",border:"1px solid var(--border-primary)",transition:"all 0.2s"},className:"note-card",children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16},children:[e.jsx("span",{style:{fontSize:11,fontWeight:700,padding:"2px 8px",borderRadius:4,background:`${O.color}15`,color:O.color},children:O.label}),e.jsx(rt,{style:{fontSize:12,color:"var(--text-tertiary)"}})]}),e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:12},children:Object.entries(w).filter(([,f])=>f&&f.trim()).map(([f,k])=>{var B,W,je,we,Pe,De,lt,Ae,Ie,$e,Et,Ft,Rt,Pt,Dt;return e.jsxs("div",{children:[e.jsx("div",{style:{fontSize:10,color:"var(--text-tertiary)",marginBottom:4,textTransform:"uppercase",fontWeight:600},children:((je=(W=(B=ke[O.label])==null?void 0:B.questions)==null?void 0:W.find(fe=>fe.key===f))==null?void 0:je.label)||((De=(Pe=(we=ke.首仓)==null?void 0:we.questions)==null?void 0:Pe.find(fe=>fe.key===f))==null?void 0:De.label)||((Ie=(Ae=(lt=ke.加仓)==null?void 0:lt.questions)==null?void 0:Ae.find(fe=>fe.key===f))==null?void 0:Ie.label)||((Ft=(Et=($e=ke.减仓)==null?void 0:$e.questions)==null?void 0:Et.find(fe=>fe.key===f))==null?void 0:Ft.label)||((Dt=(Pt=(Rt=ke.平仓)==null?void 0:Rt.questions)==null?void 0:Pt.find(fe=>fe.key===f))==null?void 0:Dt.label)||f}),e.jsx("div",{style:{fontSize:13,color:"var(--text-secondary)",lineHeight:1.5},children:k})]},f)})})]},b)})})]})})})()]})})()}),e.jsx(Ot,{title:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12},children:[F&&e.jsx("span",{style:{padding:"4px 12px",borderRadius:6,background:`${((jt=F.point)==null?void 0:jt.color)||"var(--color-brand)"}20`,color:((wt=F.point)==null?void 0:wt.color)||"var(--color-brand)",fontWeight:700,fontSize:12},children:((kt=F.point)==null?void 0:kt.label)||"复盘"}),e.jsx("span",{children:((Nt=ke[(St=F==null?void 0:F.point)==null?void 0:St.label])==null?void 0:Nt.title)||"交易复盘"})]}),open:K,onCancel:ar,onOk:rr,okText:"保存复盘",cancelText:"取消",width:520,styles:{header:{background:"var(--bg-secondary)",borderBottom:"1px solid var(--border-primary)"},body:{background:"var(--bg-primary)",padding:24},footer:{background:"var(--bg-secondary)",borderTop:"1px solid var(--border-primary)"}},children:F&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{style:{marginBottom:16,padding:12,background:"var(--bg-secondary)",borderRadius:8,fontFamily:"monospace",fontSize:12,color:"var(--text-tertiary)"},children:[((Mt=F.point)==null?void 0:Mt.time)&&ce(F.point.time).format("YYYY-MM-DD HH:mm:ss"),((Ct=F.point)==null?void 0:Ct.qty)&&` | ${F.point.qty}手`,((Tt=F.point)==null?void 0:Tt.price)&&` @ ${F.point.price.toFixed(2)}`]}),(((Lt=ke[(zt=F.point)==null?void 0:zt.label])==null?void 0:Lt.questions)||[]).map(r=>e.jsxs("div",{style:{marginBottom:16},children:[e.jsx("label",{style:{display:"block",fontSize:12,fontWeight:600,color:"var(--text-secondary)",marginBottom:6},children:r.label}),e.jsx(tt.TextArea,{value:be[r.key]||"",onChange:t=>de(s=>({...s,[r.key]:t.target.value})),placeholder:r.placeholder,rows:2,style:{background:"var(--bg-secondary)",border:"1px solid var(--border-primary)",borderRadius:6,color:"var(--text-primary)"}})]},r.key))]})}),e.jsxs(ct,{title:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[e.jsx(It,{style:{color:"var(--color-brand)"}}),e.jsx("span",{children:"表格设置"})]}),placement:"right",width:R?"100vw":320,open:Yt,onClose:()=>mt(!1),styles:{header:{background:"var(--bg-secondary)",borderBottom:"1px solid var(--border-primary)"},body:{background:"var(--bg-primary)",padding:16}},children:[e.jsxs("div",{style:{marginBottom:24},children:[e.jsxs("div",{style:{fontSize:12,fontWeight:600,color:"var(--text-secondary)",marginBottom:12,display:"flex",alignItems:"center",gap:6},children:[e.jsx(Nr,{}),"行间距"]}),e.jsxs(Ye.Group,{value:xe.rowHeight,onChange:r=>ot({rowHeight:r.target.value}),buttonStyle:"solid",style:{width:"100%"},children:[e.jsx(Ye.Button,{value:"compact",style:{width:"33.33%",textAlign:"center"},children:"紧凑"}),e.jsx(Ye.Button,{value:"middle",style:{width:"33.33%",textAlign:"center"},children:"标准"}),e.jsx(Ye.Button,{value:"large",style:{width:"33.34%",textAlign:"center"},children:"宽松"})]})]}),e.jsxs("div",{children:[e.jsxs("div",{style:{fontSize:12,fontWeight:600,color:"var(--text-secondary)",marginBottom:12,display:"flex",alignItems:"center",justifyContent:"space-between"},children:[e.jsxs("span",{style:{display:"flex",alignItems:"center",gap:6},children:[e.jsx(Mr,{}),"列显示"]}),e.jsx(te,{type:"link",size:"small",onClick:()=>ot({hiddenColumns:[]}),style:{padding:0,fontSize:11},children:"重置"})]}),e.jsx("div",{style:{background:"var(--bg-secondary)",borderRadius:8,padding:12,border:"1px solid var(--border-primary)"},children:Kt.filter(r=>!r.jigsaw||j).map(r=>e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--border-primary)"},children:[e.jsxs("span",{style:{fontSize:12,color:xe.hiddenColumns.includes(r.key)?"var(--text-tertiary)":"var(--text-primary)"},children:[r.label,r.jigsaw&&e.jsx("span",{style:{fontSize:9,marginLeft:4,color:"var(--text-tertiary)",background:"var(--bg-tertiary)",padding:"1px 4px",borderRadius:2},children:"Jigsaw"})]}),e.jsx(Cr,{size:"small",checked:!xe.hiddenColumns.includes(r.key),onChange:()=>Xt(r.key)})]},r.key))})]}),e.jsx("div",{style:{marginTop:24,padding:12,background:"rgba(212, 175, 55, 0.1)",borderRadius:8,border:"1px solid rgba(212, 175, 55, 0.2)"},children:e.jsx("div",{style:{fontSize:11,color:"var(--text-tertiary)"},children:"💡 提示：左右拖动表格可以水平滚动"})})]}),e.jsxs(ct,{title:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12},children:[e.jsx("div",{className:"hidden sm:flex",style:{width:40,height:40,borderRadius:"50%",background:"var(--bg-tertiary)",alignItems:"center",justifyContent:"center",border:"1px solid var(--border-primary)"},children:e.jsx(rt,{style:{color:"var(--text-secondary)",fontSize:18}})}),e.jsxs("div",{children:[e.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--text-primary)",letterSpacing:"-0.3px"},children:"交易复盘"}),C&&e.jsxs("div",{style:{fontSize:10,color:"var(--text-tertiary)",marginTop:2},children:[C.instrumentCode," · ",ce(C.openTime).format("MM-DD HH:mm")]})]})]}),placement:"right",width:R?"100vw":520,open:Q,onClose:()=>H(!1),styles:{header:{background:"var(--bg-primary)",borderBottom:"1px solid var(--border-primary)",padding:R?"16px":"20px 24px"},body:{background:"var(--bg-primary)",padding:R?"16px":"24px",overflow:"auto"},footer:{background:"var(--bg-primary)",borderTop:"1px solid var(--border-primary)",padding:R?"12px 16px":"16px 24px"}},footer:e.jsxs("div",{style:{display:"flex",flexDirection:R?"column":"row",justifyContent:"space-between",alignItems:R?"stretch":"center",gap:R?12:0},children:[e.jsx(te,{icon:e.jsx(Tr,{}),onClick:dr,style:{borderColor:"var(--color-brand)",color:"var(--color-brand)"},block:R,children:"保存为策略"}),e.jsxs("div",{style:{display:"flex",gap:12},children:[e.jsx(te,{onClick:()=>H(!1),style:{borderColor:"var(--border-primary)",color:"var(--text-secondary)",flex:R?1:"none"},children:"取消"}),e.jsx(te,{type:"primary",onClick:lr,style:{background:"var(--color-brand)",borderColor:"var(--color-brand)",flex:R?1:"none"},children:"保存复盘"})]})]}),children:[C&&(()=>{var z,A,O,f;const r=C.mae??((z=C.jigsawData)==null?void 0:z.mae),t=C.mfe??((A=C.jigsawData)==null?void 0:A.mfe),s=C.fills??((O=C.jigsawData)==null?void 0:O.fills),a=r!==void 0?L(r,C.instrumentCode,C.openQuantity,u):null,o=t!==void 0?L(t,C.instrumentCode,C.openQuantity,u):null,l=Le(C.pnl,a),d=ze(o,C.pnl),h=Wt(a,o,C.pnl),y=Ze(a,C.pnl,C.holdingSeconds),b=Gt(s,C.openQuantity),w=Ue(C,a,o);return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"mb-4 p-3 rounded-lg flex items-center justify-between",style:{background:"var(--bg-tertiary)"},children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"font-mono font-bold px-2 py-1 rounded",style:{background:"var(--bg-primary)",color:"var(--text-primary)"},children:C.instrumentCode}),e.jsx("span",{style:{color:C.direction==="LONG"?"var(--color-profit)":"var(--color-loss)"},children:C.direction==="LONG"?"多":"空"}),e.jsx("span",{style:{color:"var(--text-secondary)"},children:ce(C.openTime).format("YYYY-MM-DD HH:mm")})]}),e.jsxs("div",{className:"font-mono font-bold text-lg",style:{color:C.pnl>=0?"var(--color-profit)":"var(--color-loss)"},children:[C.pnl>=0?"+":"",(f=C.pnl)==null?void 0:f.toFixed(2)]})]}),(r!==void 0||t!==void 0)&&e.jsxs("div",{className:"mb-4 p-4 rounded-lg",style:{background:"var(--bg-tertiary)",border:"1px solid var(--border-primary)"},children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx($t,{style:{color:"var(--color-brand)"}}),e.jsx("span",{className:"text-sm font-semibold",style:{color:"var(--text-primary)"},children:"交易波动区间"})]}),e.jsx(Ht,{mae:r,mfe:t,pnl:C.pnl,maeUSD:a,mfeUSD:o})]}),(a||o)&&e.jsxs("div",{className:"mb-4 p-4 rounded-lg",style:{background:"var(--bg-tertiary)",border:"1px solid var(--border-primary)"},children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx(zr,{style:{color:"var(--color-brand)"}}),e.jsx("span",{className:"text-sm font-semibold",style:{color:"var(--text-primary)"},children:"高级分析指标"})]}),e.jsxs("div",{className:"grid grid-cols-3 gap-3",children:[e.jsxs("div",{className:"p-3 rounded",style:{background:"var(--bg-primary)"},children:[e.jsx(I,{title:"R-Multiple: PnL / |MAE|，衡量风险回报效率",children:e.jsxs("div",{className:"text-xs mb-1 flex items-center gap-1",style:{color:"var(--text-tertiary)"},children:["R倍数 ",e.jsx(Ce,{})]})}),e.jsx("div",{className:"text-xl font-bold font-mono",style:{color:l!==null?l>=1?"var(--color-profit)":l>=0?"var(--color-brand)":"var(--color-loss)":"var(--text-tertiary)"},children:l!==null?`${l>=0?"+":""}${l.toFixed(2)}R`:"-"})]}),e.jsxs("div",{className:"p-3 rounded",style:{background:"var(--bg-primary)"},children:[e.jsx(I,{title:d!==null&&d>100?"⚠️ 超过100%可能因分批建仓导致统计不准确":"利润捕获率: 实际盈利 / 最大浮盈，越高越好",children:e.jsxs("div",{className:"text-xs mb-1 flex items-center gap-1",style:{color:"var(--text-tertiary)"},children:["利润捕获 ",e.jsx(Ce,{})]})}),e.jsxs("div",{className:"text-xl font-bold font-mono flex items-center gap-1",style:{color:d!==null?d>100?"#f59e0b":d>=70?"var(--color-profit)":d<30?"var(--color-loss)":"var(--color-brand)":"var(--text-tertiary)"},children:[d!==null?`${d.toFixed(0)}%`:"-",d!==null&&d>100&&e.jsx("span",{style:{fontSize:12},children:"⚠"})]})]}),e.jsxs("div",{className:"p-3 rounded",style:{background:"var(--bg-primary)"},children:[e.jsx(I,{title:"风险占用比: |MAE|/(|PnL|或MFE)，评估承担的风险",children:e.jsxs("div",{className:"text-xs mb-1 flex items-center gap-1",style:{color:"var(--text-tertiary)"},children:["风险占用 ",e.jsx(Ce,{})]})}),e.jsx("div",{className:"text-xl font-bold font-mono",style:{color:h!==null?h<.5?"var(--color-profit)":h>2?"var(--color-loss)":"var(--color-brand)":"var(--text-tertiary)"},children:h!==null?h.toFixed(2):"-"})]}),e.jsxs("div",{className:"p-3 rounded",style:{background:"var(--bg-primary)"},children:[e.jsx(I,{title:"心理压力系数: 根据MAE占比和持仓时长计算",children:e.jsxs("div",{className:"text-xs mb-1 flex items-center gap-1",style:{color:"var(--text-tertiary)"},children:["心理压力 ",e.jsx(Ce,{})]})}),e.jsx("div",{className:"mt-1",children:e.jsx(Jr,{score:y})})]}),e.jsxs("div",{className:"p-3 rounded",style:{background:"var(--bg-primary)"},children:[e.jsx(I,{title:"执行复杂度: Fills/Quantity，值越高说明操作越频繁",children:e.jsxs("div",{className:"text-xs mb-1 flex items-center gap-1",style:{color:"var(--text-tertiary)"},children:["执行复杂度 ",e.jsx(Ce,{})]})}),e.jsx("div",{className:"text-xl font-bold font-mono",style:{color:b!==null?b<=2?"var(--color-profit)":b>4?"var(--color-loss)":"var(--color-brand)":"var(--text-tertiary)"},children:b!==null?b.toFixed(1):"-"})]}),e.jsxs("div",{className:"p-3 rounded",style:{background:"var(--bg-primary)"},children:[e.jsx("div",{className:"text-xs mb-1",style:{color:"var(--text-tertiary)"},children:"持仓时长"}),e.jsx("div",{className:"text-xl font-bold font-mono",style:{color:"var(--text-primary)"},children:Xe(C.holdingSeconds)})]})]})]}),w.length>0&&e.jsxs("div",{className:"mb-4 p-4 rounded-lg",style:{background:"var(--bg-tertiary)",border:"1px solid var(--border-primary)"},children:[e.jsxs("div",{className:"flex items-center gap-2 mb-3",children:[e.jsx(Bt,{style:{color:"var(--color-brand)"}}),e.jsx("span",{className:"text-sm font-semibold",style:{color:"var(--text-primary)"},children:"自动归因诊断"})]}),e.jsx("div",{className:"space-y-2",children:w.map((k,B)=>e.jsxs("div",{className:"flex items-start gap-3 p-2 rounded",style:{background:k.color+"10"},children:[e.jsxs("div",{className:"w-6 h-6 rounded flex items-center justify-center flex-shrink-0 mt-0.5",style:{background:k.color+"30"},children:[k.type==="greed"&&e.jsx(Lr,{style:{color:k.color,fontSize:12}}),k.type==="badExit"&&e.jsx(Er,{style:{color:k.color,fontSize:12}}),k.type==="hesitation"&&e.jsx(Fr,{style:{color:k.color,fontSize:12}}),k.type==="perfect"&&e.jsx(Rr,{style:{color:k.color,fontSize:12}}),k.type==="pressure"&&e.jsx(Pr,{style:{color:k.color,fontSize:12}})]}),e.jsxs("div",{children:[e.jsx("div",{className:"text-sm font-semibold",style:{color:k.color},children:k.label}),e.jsx("div",{className:"text-xs mt-0.5",style:{color:"var(--text-secondary)"},children:k.description})]})]},B))})]})]})})(),e.jsxs(ne,{form:ae,layout:"vertical",children:[e.jsx(ne.Item,{name:"strategyIds",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"交易策略"}),children:e.jsx(ve,{mode:"multiple",placeholder:"选择使用的策略...",options:D.map(r=>({value:r.id,label:r.name}))})}),e.jsxs("div",{style:{fontSize:12,fontWeight:600,color:"var(--text-tertiary)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:16,marginTop:24,display:"flex",alignItems:"center",gap:8},children:[e.jsx("div",{style:{width:12,height:1,background:"var(--border-primary)"}}),"复盘记录"]}),e.jsx(ne.Item,{name:"entryReason",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"入场理由"}),children:e.jsx(Ke,{rows:2,placeholder:"为什么在这个点位入场？看到了什么信号？",style:{resize:"none"}})}),e.jsx(ne.Item,{name:"stopLossReason",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"止损理由"}),children:e.jsx(Ke,{rows:2,placeholder:"止损位设置的依据是什么？",style:{resize:"none"}})}),e.jsx(ne.Item,{name:"takeProfitReason",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"止盈理由"}),children:e.jsx(Ke,{rows:2,placeholder:"止盈目标是如何确定的？",style:{resize:"none"}})}),e.jsx(ne.Item,{name:"notes",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"其他备注"}),children:e.jsx(Ke,{rows:2,placeholder:"心态、失误、可改进之处...",style:{resize:"none"}})})]})]}),e.jsx(Ot,{title:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[e.jsx(Bt,{style:{color:"var(--color-brand)"}}),e.jsx("span",{children:"将复盘内容保存为策略"})]}),open:Me,onCancel:()=>at(!1),onOk:cr,okText:"创建策略",cancelText:"取消",width:480,styles:{header:{background:"var(--bg-primary)",borderBottom:"1px solid var(--border-primary)"},body:{background:"var(--bg-primary)",padding:"24px"},footer:{background:"var(--bg-primary)",borderTop:"1px solid var(--border-primary)"}},children:e.jsxs(ne,{form:Be,layout:"vertical",children:[e.jsx(ne.Item,{name:"name",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"策略名称"}),rules:[{required:!0,message:"请输入策略名称"}],children:e.jsx(tt,{placeholder:"例如：突破回踩做多、假突破反转..."})}),e.jsx(ne.Item,{name:"category",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"策略分类"}),children:e.jsx(ve,{options:[{value:"趋势",label:"趋势策略"},{value:"突破",label:"突破策略"},{value:"反转",label:"反转策略"},{value:"区间",label:"区间策略"},{value:"剥头皮",label:"剥头皮策略"},{value:"套利",label:"套利策略"},{value:"实验",label:"实验策略"},{value:"通用",label:"通用策略"}]})}),e.jsx(ne.Item,{name:"color",label:e.jsx("span",{style:{color:"var(--text-secondary)",fontSize:12},children:"标签颜色"}),children:e.jsx(ve,{options:[{value:"#eab308",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#eab308",marginRight:8}}),"金色"]})},{value:"#10b981",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#10b981",marginRight:8}}),"绿色"]})},{value:"#3b82f6",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#3b82f6",marginRight:8}}),"蓝色"]})},{value:"#f43f5e",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#f43f5e",marginRight:8}}),"红色"]})},{value:"#8B5CF6",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#8B5CF6",marginRight:8}}),"紫色"]})},{value:"#06B6D4",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#06B6D4",marginRight:8}}),"青色"]})},{value:"#F97316",label:e.jsxs("span",{children:[e.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:2,background:"#F97316",marginRight:8}}),"橙色"]})}]})}),e.jsxs("div",{style:{background:"var(--bg-tertiary)",border:"1px solid var(--border-primary)",borderRadius:8,padding:16,marginTop:8},children:[e.jsx("div",{style:{fontSize:11,color:"var(--text-tertiary)",marginBottom:8,textTransform:"uppercase",letterSpacing:"0.5px"},children:"策略描述预览"}),e.jsx("div",{style:{fontSize:13,color:"var(--text-secondary)",lineHeight:1.6,whiteSpace:"pre-wrap"},children:(()=>{const r=ae.getFieldsValue(),t=[];return r.entryReason&&t.push(`【入场】${r.entryReason}`),r.stopLossReason&&t.push(`【止损】${r.stopLossReason}`),r.takeProfitReason&&t.push(`【止盈】${r.takeProfitReason}`),r.notes&&t.push(`【备注】${r.notes}`),t.join(`
`)||"（请先填写复盘内容）"})()})]})]})}),e.jsx("style",{children:`
        .binance-table .ant-table {
          background: transparent !important;
        }
        .binance-table .ant-table-thead > tr > th {
          background: var(--bg-tertiary) !important;
          color: var(--text-secondary) !important;
          font-weight: 600 !important;
          font-size: 11px !important;
          text-transform: uppercase !important;
          letter-spacing: 0.8px !important;
          border-bottom: 1px solid var(--border-primary) !important;
          padding: 16px 20px !important;
        }
        .binance-table .ant-table-tbody > tr > td {
          background: var(--bg-secondary) !important;
          border-bottom: 1px solid var(--border-primary) !important;
          padding: 18px 20px !important;
          transition: background 0.15s ease !important;
        }
        .binance-table .ant-table-tbody > tr:hover > td {
          background: var(--bg-hover) !important;
        }
        .binance-table .ant-table-tbody > tr.ant-table-row-selected > td {
          background: var(--color-brand-bg) !important;
        }
        .binance-table .ant-pagination {
          margin: 16px !important;
        }
        .binance-table .ant-pagination-item {
          background: var(--bg-tertiary) !important;
          border-color: var(--border-primary) !important;
        }
        .binance-table .ant-pagination-item a {
          color: var(--text-secondary) !important;
        }
        .binance-table .ant-pagination-item-active {
          background: var(--color-brand) !important;
          border-color: var(--color-brand) !important;
        }
        .binance-table .ant-pagination-item-active a {
          color: var(--bg-primary) !important;
        }
        .binance-table .ant-table-column-sorter {
          color: var(--text-tertiary) !important;
        }
        .binance-table .ant-table-column-sorter-up.active,
        .binance-table .ant-table-column-sorter-down.active {
          color: var(--color-brand) !important;
        }
        .binance-table .ant-empty-description {
          color: var(--text-tertiary) !important;
        }
        .binance-table .ant-spin-dot-item {
          background-color: var(--color-brand) !important;
        }
        
        /* 拖动滚动 */
        .binance-table .ant-table-body {
          cursor: grab;
        }
        .binance-table .ant-table-body:active {
          cursor: grabbing;
        }
        
        /* 行高 - 紧凑 */
        .row-height-compact .ant-table-thead > tr > th {
          padding: 8px 12px !important;
          font-size: 10px !important;
        }
        .row-height-compact .ant-table-tbody > tr > td {
          padding: 6px 12px !important;
        }
        .row-height-compact .ant-table-tbody > tr > td * {
          font-size: 11px !important;
        }
        
        /* 行高 - 标准 (默认) */
        .row-height-middle .ant-table-thead > tr > th {
          padding: 12px 16px !important;
        }
        .row-height-middle .ant-table-tbody > tr > td {
          padding: 12px 16px !important;
        }
        
        /* 行高 - 宽松 */
        .row-height-large .ant-table-thead > tr > th {
          padding: 18px 20px !important;
        }
        .row-height-large .ant-table-tbody > tr > td {
          padding: 20px 20px !important;
        }
        .row-height-large .ant-table-tbody > tr > td * {
          font-size: 14px !important;
        }
        
        /* MAE/MFE 内联编辑输入框 */
        .mae-mfe-input {
          background: var(--bg-tertiary) !important;
          border-color: var(--color-brand) !important;
        }
        .mae-mfe-input .ant-input-number-input {
          color: var(--text-primary) !important;
          font-family: 'JetBrains Mono', monospace !important;
          font-size: 12px !important;
        }
        .mae-mfe-input .ant-input-number-prefix {
          color: var(--text-tertiary) !important;
        }
        
        /* 合并组行样式 */
        .merged-group-row > td {
          background: rgba(234, 179, 8, 0.03) !important;
        }
        .merged-group-row:hover > td {
          background: rgba(234, 179, 8, 0.08) !important;
        }
        
        /* 展开行样式 */
        .binance-table .ant-table-expanded-row > td {
          background: var(--bg-tertiary) !important;
          padding: 0 !important;
        }

        /* 专业金融风格持仓曲线图样式 */
        .professional-chart-container {
          padding: 24px;
          background: var(--bg-primary);
        }

        .pro-stats-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 24px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--border-primary);
        }

        .pro-stat-group {
          display: flex;
          gap: 32px;
        }

        .pro-stat-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .pro-label {
          font-size: 10px;
          color: var(--text-tertiary);
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .pro-value {
          font-size: 18px;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
          color: var(--text-primary);
        }

        .pro-value.profit { color: #22c55e; }
        .pro-value.loss { color: #ef4444; }
        .pro-value.long { color: #22c55e; }
        .pro-value.short { color: #ef4444; }

        .pro-controls {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .pro-scale-badge {
          font-size: 10px;
          padding: 2px 6px;
          background: var(--bg-tertiary);
          border-radius: 4px;
          color: var(--text-tertiary);
          font-family: monospace;
        }

        .pro-reset-btn {
          padding: 4px 10px;
          font-size: 10px;
          background: transparent;
          border: 1px solid var(--border-primary);
          border-radius: 4px;
          color: var(--text-secondary);
          cursor: pointer;
          transition: all 0.2s;
        }

        .pro-reset-btn:hover {
          background: var(--bg-tertiary);
          color: var(--text-primary);
        }

        .pro-svg-wrapper {
          background: #0d1117; /* 深色背景更显专业 */
          border: 1px solid var(--border-primary);
          border-radius: 8px;
          overflow: hidden;
        }

        .pro-svg {
          display: block;
        }

        /* 兼容旧样式 */
        .minimal-chart-container {
          padding: 32px;
          background: var(--bg-primary);
        }

        .chart-header {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }

        /* 现代专业持仓图表样式 */
        .modern-chart-container {
          padding: 24px;
          background: var(--bg-primary);
          color: var(--text-primary);
        }

        .modern-chart-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 24px;
          padding-bottom: 20px;
          border-bottom: 1px solid var(--border-primary);
        }

        .header-info .direction-tag {
          font-size: 12px;
          font-weight: 800;
          letter-spacing: 1.5px;
          margin-bottom: 8px;
        }

        .stats-group {
          display: flex;
          gap: 32px;
        }

        .stat {
          display: flex;
          flex-direction: column;
        }

        .stat .label {
          font-size: 10px;
          color: var(--text-tertiary);
          letter-spacing: 1px;
          margin-bottom: 4px;
        }

        .stat .value {
          font-size: 24px;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
        }

        .header-controls {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 12px;
        }

        .legend {
          display: flex;
          gap: 16px;
        }

        .legend .item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          color: var(--text-secondary);
        }

        .legend .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
        }

        .legend .line {
          width: 16px;
        }

        .reset-btn {
          padding: 4px 12px;
          font-size: 10px;
          font-weight: 700;
          background: var(--bg-tertiary);
          border: 1px solid var(--border-primary);
          color: var(--text-secondary);
          border-radius: 4px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .reset-btn:hover {
          background: var(--text-primary);
          color: var(--bg-primary);
        }

        .modern-svg-wrapper {
          background: var(--bg-secondary);
          border-radius: 12px;
          border: 1px solid var(--border-primary);
          overflow: hidden;
          box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);
        }

        .modern-svg {
          display: block;
        }

        /* 复盘节点悬停效果 */
        .review-label-btn {
          transition: transform 0.2s;
        }
        .review-label-btn:hover {
          transform: scale(1.1);
        }

        @keyframes pulse-soft {
          0% { opacity: 0.7; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.02); }
          100% { opacity: 0.7; transform: scale(1); }
        }

        /* 复盘标签按钮 */
        .review-label-btn:hover rect {
          fill: rgba(255,255,255,0.1) !important;
          stroke: currentColor !important;
        }

        /* 复盘弹窗覆盖层 */
        .review-modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.6);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          backdrop-filter: blur(4px);
        }

        .review-modal {
          background: var(--bg-primary);
          border: 1px solid var(--border-primary);
          border-radius: 12px;
          width: 480px;
          max-width: 90vw;
          max-height: 80vh;
          overflow: hidden;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .review-modal-header {
          padding: 20px 24px;
          border-bottom: 1px solid var(--border-primary);
          background: var(--bg-secondary);
        }

        .review-modal-title {
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 16px;
          font-weight: 600;
          color: var(--text-primary);
        }

        .review-label-badge {
          padding: 4px 12px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 700;
        }

        .review-modal-meta {
          margin-top: 8px;
          font-size: 12px;
          color: var(--text-tertiary);
          font-family: 'JetBrains Mono', monospace;
        }

        .review-modal-body {
          padding: 20px 24px;
          max-height: 400px;
          overflow-y: auto;
        }

        .review-question {
          margin-bottom: 16px;
        }

        .review-question label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          color: var(--text-secondary);
          margin-bottom: 6px;
        }

        .review-question textarea {
          width: 100%;
          padding: 10px 12px;
          border: 1px solid var(--border-primary);
          border-radius: 6px;
          background: var(--bg-secondary);
          color: var(--text-primary);
          font-size: 13px;
          resize: vertical;
          transition: border-color 0.2s;
        }

        .review-question textarea:focus {
          outline: none;
          border-color: var(--color-brand);
        }

        .review-question textarea::placeholder {
          color: var(--text-tertiary);
        }

        .review-modal-footer {
          padding: 16px 24px;
          border-top: 1px solid var(--border-primary);
          display: flex;
          justify-content: flex-end;
          gap: 12px;
          background: var(--bg-secondary);
        }

        .review-btn-cancel, .review-btn-save {
          padding: 8px 20px;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }

        .review-btn-cancel {
          background: transparent;
          border: 1px solid var(--border-primary);
          color: var(--text-secondary);
        }

        .review-btn-cancel:hover {
          background: var(--bg-tertiary);
          color: var(--text-primary);
        }

        .review-btn-save {
          background: var(--color-brand);
          border: none;
          color: #0a0a0c;
        }

        .review-btn-save:hover {
          filter: brightness(1.1);
        }

        /* 复盘笔记汇总 */
        .review-summary {
          margin-top: 20px;
          padding: 16px;
          background: var(--bg-secondary);
          border: 1px solid var(--border-primary);
          border-radius: 8px;
        }

        .review-summary-title {
          font-size: 13px;
          font-weight: 600;
          color: var(--text-primary);
          margin-bottom: 12px;
          display: flex;
          align-items: center;
        }

        .review-summary-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .review-summary-item {
          padding: 12px;
          background: var(--bg-primary);
          border: 1px solid var(--border-primary);
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .review-summary-item:hover {
          border-color: var(--color-brand);
        }

        .review-item-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 8px;
        }

        .review-item-label {
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 10px;
          font-weight: 700;
        }

        .review-item-time {
          font-size: 10px;
          color: var(--text-tertiary);
          font-family: 'JetBrains Mono', monospace;
        }

        .review-item-content {
          font-size: 11px;
        }

        .review-item-note {
          margin-bottom: 4px;
          line-height: 1.4;
        }

        .review-item-note .note-label {
          color: var(--text-tertiary);
          margin-right: 4px;
        }

        .review-item-note .note-value {
          color: var(--text-secondary);
        }

        /* 兼容旧样式 */
        .professional-chart-container {
          padding: 16px 20px;
          background: var(--bg-secondary);
        }

        .chart-header {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }

        .direction-badge {
          font-size: 13px;
          font-weight: 700;
          padding: 6px 14px;
          border-radius: 8px;
        }

        .chart-legend {
          display: flex;
          gap: 14px;
          flex-wrap: wrap;
        }

        .legend-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          color: var(--text-secondary);
        }

        .legend-item .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
        }

        .legend-item .line-sample {
          width: 16px;
          height: 0;
          border-top: 2px dashed;
        }

        .chart-controls {
          margin-left: auto;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .scale-label {
          font-size: 10px;
          color: var(--text-tertiary);
          font-family: 'JetBrains Mono', monospace;
        }

        .scale-handle {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 28px;
          height: 28px;
          background: var(--bg-tertiary);
          border: 1px solid var(--border-primary);
          border-radius: 6px;
          cursor: ns-resize;
          color: var(--text-secondary);
          transition: all 0.2s;
        }

        .scale-handle:hover {
          background: var(--color-brand);
          color: var(--bg-primary);
          border-color: var(--color-brand);
        }

        .scale-btn {
          padding: 4px 10px;
          font-size: 10px;
          background: var(--bg-tertiary);
          border: 1px solid var(--border-primary);
          border-radius: 4px;
          color: var(--text-secondary);
          cursor: pointer;
          transition: all 0.2s;
        }

        .scale-btn:hover {
          background: var(--bg-primary);
          color: var(--text-primary);
        }

        .chart-scroll-container {
          border-radius: 8px;
          background: linear-gradient(180deg, rgba(0,0,0,0.15) 0%, transparent 100%);
        }

        .position-chart-svg {
          display: block;
          margin-bottom: 16px;
          border-radius: 8px;
          background: linear-gradient(180deg, rgba(0,0,0,0.2) 0%, transparent 100%);
        }

        /* 底部交易明细 */
        .trade-summary-row {
          display: flex;
          gap: 12px;
          overflow-x: auto;
          padding: 4px 0;
        }

        .summary-item {
          flex: 0 0 auto;
          min-width: 160px;
          background: var(--bg-tertiary);
          border-radius: 8px;
          padding: 12px;
          border: 1px solid var(--border-primary);
          transition: all 0.2s;
        }

        .summary-item:hover {
          border-color: var(--color-brand);
        }

        .summary-item.float-profit {
          border-left: 3px solid var(--color-profit);
        }

        .summary-item.float-loss {
          border-left: 3px solid #f59e0b;
        }

        .summary-header {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 10px;
        }

        .summary-num {
          font-size: 10px;
          font-weight: 700;
          color: var(--color-brand);
          background: rgba(234, 179, 8, 0.1);
          padding: 2px 6px;
          border-radius: 4px;
        }

        .summary-label {
          font-size: 11px;
          font-weight: 700;
        }

        .float-amount {
          font-size: 10px;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
        }

        .close-float-amount {
          font-size: 10px;
          font-weight: 600;
          font-family: 'JetBrains Mono', monospace;
          margin-left: 4px;
        }

        .summary-body {
          display: flex;
          flex-direction: column;
          gap: 6px;
          font-family: 'JetBrains Mono', monospace;
        }

        .summary-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .summary-qty {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
        }

        .summary-price {
          font-size: 11px;
          color: var(--text-secondary);
        }

        .summary-avg {
          font-size: 10px;
          color: var(--text-tertiary);
          padding: 2px 6px;
          background: var(--bg-primary);
          border-radius: 4px;
        }

        .summary-close {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          padding-top: 6px;
          border-top: 1px dashed var(--border-primary);
        }

        .close-price {
          color: var(--text-tertiary);
        }

        .summary-pnl {
          font-size: 15px;
          font-weight: 700;
          margin-top: 4px;
        }
      `})]})});return oe?yr.createPortal(ht,document.body):ht};export{na as default};
